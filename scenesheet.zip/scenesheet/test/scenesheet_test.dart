import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter_test/flutter_test.dart';
import 'package:scenesheet/models/scene_model.dart';
import 'package:scenesheet/parsers/mixer_parser.dart';
import 'package:scenesheet/parsers/mixer_detector.dart';
import 'package:scenesheet/parsers/scene_parser.dart';
import 'package:scenesheet/parsers/soundcraft_parser.dart';
import 'package:scenesheet/parsers/x32_parser.dart';
import 'package:scenesheet/parsers/yamaha_parser.dart';
import 'package:scenesheet/services/image_export_service.dart';
import 'package:scenesheet/services/pdf_export_service.dart';

MixerFile _bytes(String name, String s) => MixerFile(name, Uint8List.fromList(latin1.encode(s)));
Matcher _msg(String m) => throwsA(isA<SceneException>().having((e) => e.message, 'message', m));

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final scn = MixerFile('28-8.scn', File('test/fixtures/28-8.scn').readAsBytesSync());

  test('X32/M32 scene still parses', () {
    final s = SceneParser.parse(scn);
    expect(s.name, '28-8');
    expect(s.channels.length, 32);
    expect(s.channels.first.name, 'Presenter');
    expect(s.channels[21].name, 'Ride');
    expect(s.buses.length, 16);
    expect(s.buses.first.name, 'Main');
    expect(s.matrices.first.name, 'Aux 1 out');
    expect(s.auxes[6].name, 'USB L');
    expect(s.main.first.insert, 'FX7L');
    expect(s.fxReturns.first.device, 'GEQ2');
    expect(s.fxSlots.first.device, 'WAVD');
  });

  MixerFile fx(String path) => MixerFile(path.split('/').last, File('test/fixtures/$path').readAsBytesSync());

  test('unsupported / corrupt files do not crash', () {
    expect(() => SceneParser.parse(MixerFile('a.bin', Uint8List.fromList([1, 2, 3]))), _msg('Unsupported mixer file format.'));
    expect(() => SceneParser.parse(_bytes('x.scn', '#4.0# garbage')), _msg('Unsupported mixer file format.'));
    expect(() => SceneParser.parse(_bytes('x.json', '{"i.0.name": "x", "schema": "6", "firmware": "1"')), _msg('Could not read this mixer file.'));
  });

  test('detection picks the right parser from file contents', () {
    expect(MixerDetector.detect(scn), isA<X32Parser>());
    expect(MixerDetector.detect(fx('ql5/pfql_base.CLF')), isA<YamahaQlParser>());
    expect(MixerDetector.detect(fx('ui24/on_tap.json')), isA<SoundcraftUiParser>());
    expect(MixerDetector.detect(fx('ui24/template.uisnapshot')), isA<SoundcraftUiParser>());
  });

  test('Yamaha QL5 real fixtures (QL Editor 5.8.1.27)', () {
    final b = SceneParser.parse(fx('ql5/pfql_base.CLF'));
    expect(b.model, 'QL [OSX, 5.8.1.27]');
    expect(b.channels.length, 64);
    expect(b.channels[0].name, 'ch 1');
    expect(b.channels[0].physical, 'INPUT 1');
    expect(b.channels[11].physical, 'INPUT 12');
    expect(b.channels[32].physical, 'DANTE 1');
    expect(b.buses, isEmpty);
    expect(SceneParser.parse(fx('ql5/pfql_name.CLF')).channels[7].name, 'ZZTOP');
    final m = SceneParser.parse(fx('ql5/pfql_mod3.CLF'));
    expect(m.channels[3].physical, 'DANTE 1');
    expect(m.channels[11].physical, 'DANTE 2');
  });

  test('Yamaha CL and other Soundcraft families are detect-only', () {
    expect(() => YamahaClParser().parse(fx('ql5/pfql_base.CLF')), _msg('Yamaha CL detected, but this file format is not supported yet.'));
    expect(() => SoundcraftParser('').parse(fx('ui24/on_tap.json')),
        _msg('Soundcraft file format detected, but this format is not supported yet.'));
  });

  test('Soundcraft Ui24 real fixtures (JSON + .uisnapshot)', () {
    for (final f in ['ui24/on_tap.json', 'ui24/template.uisnapshot']) {
      final u = SceneParser.parse(fx(f));
      expect(u.mixer, 'Soundcraft Ui');
      expect(u.model, contains('ui24'));
      expect(u.channels.length, 28);
      expect(u.channels[2].name, 'HAYLEY VOCALS');
      expect(u.buses.length, 6);
      expect(u.buses[1].name, 'GUITARS/BASS');
      expect(u.auxes.length, 10);
      expect(u.auxes[1].name, 'DAN MONITOR');
      expect(u.main.first.name, 'MASTER');
      expect(u.fxReturns.length, 4);
      expect(u.fxCount, 4);
    }
    final j = SceneParser.parse(fx('ui24/on_tap.json'));
    expect(j.channels[3].physical, 'Input 4');
    expect(j.channels[2].grp, 'M1 S1');
    expect(j.channels.firstWhere((c) => c.id == 'L1').link, 1);
    expect(j.channels.firstWhere((c) => c.id == 'L2').link, 2);
    expect(j.fxReturns[3].device, 'type 3');
  });

  test('every format renders to PDF (A4, A3, Screen)', () async {
    for (final f in ['ql5/pfql_base.CLF', 'ui24/on_tap.json']) {
      final sc = SceneParser.parse(fx(f));
      for (final fmt in OutputFormat.values) {
        final pdf = await PdfExportService.build(sc, SheetOptions(sections: Set.of(Section.values), format: fmt));
        expect(latin1.decode(pdf.sublist(0, 4)), '%PDF');
      }
    }
  });

  test('Android launcher icon files are configured', () {
    const r = 'android/app/src/main/res';
    for (final d in ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
      expect(File('$r/mipmap-$d/ic_launcher.png').existsSync(), isTrue);
      expect(File('$r/drawable-$d/ic_launcher_foreground.png').existsSync(), isTrue);
    }
    final xml = File('$r/mipmap-anydpi-v26/ic_launcher.xml').readAsStringSync();
    expect(xml, contains('adaptive-icon'));
    expect(xml, contains('@drawable/ic_launcher_foreground'));
    expect(File('$r/values/ic_launcher_background.xml').existsSync(), isTrue);
  });

  test('PDF: A4, A3 and Screen generate with correct page size', () async {
    final s = SceneParser.parse(scn);
    final all = Set.of(Section.values);
    double w(Uint8List b) {
      final m = RegExp(r'/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)').firstMatch(latin1.decode(b))!;
      return double.parse(m[1]!);
    }

    final a4 = await PdfExportService.build(s, SheetOptions(sections: all, format: OutputFormat.a4));
    final a3 = await PdfExportService.build(s, SheetOptions(sections: all, format: OutputFormat.a3));
    final sc = await PdfExportService.build(s, SheetOptions(sections: all, format: OutputFormat.screen));
    expect(w(a4), closeTo(841.9, 1));
    expect(w(a3), closeTo(1190.6, 1));
    expect(w(sc), 600);
  });

  testWidgets('image flatten gives opaque white background', (t) async {
    await t.runAsync(() async {
      final rec = ui.PictureRecorder();
      ui.Canvas(rec);
      final img = await rec.endRecording().toImage(4, 4); // fully transparent
      final png = (await img.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
      final flat = await ImageExportService.flattenOnWhite(png);
      final out = (await (await (await ui.instantiateImageCodec(flat)).getNextFrame()).image
              .toByteData(format: ui.ImageByteFormat.rawRgba))!
          .buffer
          .asUint8List();
      expect(out.every((b) => b == 255), isTrue);
    });
  });
}
