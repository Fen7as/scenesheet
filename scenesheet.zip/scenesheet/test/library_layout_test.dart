import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:scenesheet/models/scene_model.dart';
import 'package:scenesheet/parsers/mixer_parser.dart';
import 'package:scenesheet/parsers/scene_parser.dart';
import 'package:scenesheet/services/pdf_export_service.dart';
import 'package:scenesheet/services/scene_library_service.dart';

MixerFile fx(String p) => MixerFile(p.split('/').last, File('test/fixtures/$p').readAsBytesSync());
const _fixtures = ['28-8.scn', 'ql5/pfql_base.CLF', 'ui24/on_tap.json'];
MixerFile load(String p) =>
    p == '28-8.scn' ? MixerFile('28-8.scn', File('test/fixtures/28-8.scn').readAsBytesSync()) : fx(p);

void main() {
  group('Scene library (real fixture files)', () {
    late Directory tmp;
    late SceneLibrary lib;
    var tick = 0;
    setUp(() {
      tmp = Directory.systemTemp.createTempSync('sslib');
      tick = 0;
      lib = SceneLibrary(Directory('${tmp.path}/scenes'), now: () => DateTime(2026, 1, 1).add(Duration(minutes: tick++)));
    });
    tearDown(() => tmp.deleteSync(recursive: true));

    test('import stores a local copy that survives deleting the original', () async {
      final original = File('${tmp.path}/Sunday_Service.scn')..writeAsBytesSync(load('28-8.scn').bytes);
      final e = await lib.add(MixerFile('Sunday_Service.scn', original.readAsBytesSync()));
      original.deleteSync();
      expect(original.existsSync(), isFalse);
      final f = await lib.open(e);
      expect(SceneParser.parse(f).channels.length, 32);
      expect(lib.fileOf(e).existsSync(), isTrue); // share source = stored copy
    });

    test('Last Opened sorting and delete removes only the local copy', () async {
      final ext = File('${tmp.path}/ext.CLF')..writeAsBytesSync(load('ql5/pfql_base.CLF').bytes);
      final a = await lib.add(MixerFile('a.scn', load('28-8.scn').bytes));
      final b = await lib.add(MixerFile('ext.CLF', ext.readAsBytesSync()));
      expect((await lib.list()).map((e) => e.name), ['ext.CLF', 'a.scn']);
      await lib.open(a);
      expect((await lib.list()).first.name, 'a.scn');
      await lib.delete(b);
      expect((await lib.list()).map((e) => e.name), ['a.scn']);
      expect(lib.fileOf(b).existsSync(), isFalse);
      expect(ext.existsSync(), isTrue); // original untouched
    });

    test('re-importing identical content does not duplicate; no list limit', () async {
      final m = MixerFile('x.scn', load('28-8.scn').bytes);
      await lib.add(m);
      await lib.add(m);
      expect((await lib.list()).length, 1);
      for (var i = 0; i < 60; i++) {
        await lib.add(MixerFile('n$i.scn', load('28-8.scn').bytes));
      }
      expect((await lib.list()).length, 61);
    });
  });

  group('Layout: tables are never split', () {
    for (final f in _fixtures) {
      for (final fmt in OutputFormat.values) {
        for (final compact in [false, true]) {
          test('$f $fmt compact=$compact', () {
            final s = SceneParser.parse(load(f));
            final o = SheetOptions(sections: Set.of(Section.values), format: fmt, compact: compact);
            final p = PdfExportService.plan(s, o);
            final expected = {
              'Channel': s.channels.length, 'Bus': s.buses.length, 'Matrix': s.matrices.length,
              'Aux': s.auxes.length, 'Main': s.main.length, 'FX-1': s.fxReturns.length, 'FX-2': s.fxSlots.length,
            }..removeWhere((k, v) => v == 0);
            final seen = <String, int>{};
            for (final page in p.pages) {
              for (final t in page) {
                seen[t.title] = (seen[t.title] ?? 0) + 1;
                expect(t.rows, expected[t.title]); // complete table, all rows, header with it
                expect(t.x >= 0 && t.y >= 0 && t.x + t.w <= p.contentW + 0.5 && t.y + t.h <= p.contentH + 0.5, isTrue,
                    reason: '${t.title} inside page');
                expect(t.fs >= (fmt == OutputFormat.screen ? 7.0 : 5.5) - 1e-6, isTrue);
              }
              for (var i = 0; i < page.length; i++) {
                for (var j = i + 1; j < page.length; j++) {
                  final a = page[i], b = page[j];
                  final overlap = a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
                  expect(overlap, isFalse, reason: '${a.title}/${b.title} overlap');
                }
              }
            }
            expect(seen.keys.toSet(), expected.keys.toSet());
            expect(seen.values.every((n) => n == 1), isTrue);
          });
        }
      }
    }

    test('Compact uses no more pages than normal; text size changes real layout', () {
      final s = SceneParser.parse(load('ql5/pfql_base.CLF'));
      Set<Section> all() => Set.of(Section.values);
      final n = PdfExportService.plan(s, SheetOptions(sections: all(), format: OutputFormat.a4));
      final c = PdfExportService.plan(s, SheetOptions(sections: all(), format: OutputFormat.a4, compact: true));
      expect(c.pages.length <= n.pages.length, isTrue);
      final x = load('28-8.scn');
      final sc = SceneParser.parse(x);
      PlacedTable bus(double z) => PdfExportService.plan(
              sc, SheetOptions(sections: {Section.bus}, format: OutputFormat.a3, textScale: z))
          .pages.first.first;
      expect(bus(1.4).fs > bus(1.0).fs, isTrue);
      expect(bus(1.4).h > bus(1.0).h, isTrue);
    });
  });
}
