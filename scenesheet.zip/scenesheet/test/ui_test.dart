import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:scenesheet/models/scene_model.dart';
import 'package:scenesheet/screens/help_about_screen.dart';
import 'package:scenesheet/services/app_info.dart';
import 'package:scenesheet/widgets/app_signature.dart';
import 'package:scenesheet/widgets/scene_page_viewer.dart';
import 'package:scenesheet/widgets/sheet_options_panel.dart';

void mockVersion() {
  AppInfo.resetForTest();
  PackageInfo.setMockInitialValues(
      appName: 'SceneSheet', packageName: 'x.y', version: '0.8.0', buildNumber: '7', buildSignature: '');
}

Future<Uint8List> png() async {
  final rec = ui.PictureRecorder();
  ui.Canvas(rec);
  final img = await rec.endRecording().toImage(8, 8);
  return (await img.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
}

void main() {
  testWidgets('Home signature shows version name from package metadata', (t) async {
    mockVersion();
    await t.pumpWidget(const MaterialApp(home: Scaffold(body: AppSignature(showVersion: true))));
    await t.pumpAndSettle();
    expect(find.text('By R. Fenhas'), findsOneWidget);
    expect(find.text('v0.8.0'), findsOneWidget);
  });

  testWidgets('About shows name, version + build number and signature', (t) async {
    mockVersion();
    await t.pumpWidget(const MaterialApp(home: HelpAboutScreen()));
    await t.pumpAndSettle();
    expect(find.text('SceneSheet'), findsOneWidget);
    expect(find.text('Version 0.8.0 (build 7)'), findsOneWidget);
    expect(find.text('By R. Fenhas'), findsOneWidget);
  });

  testWidgets('Text Size buttons are disabled when Compact is on, enabled when off', (t) async {
    IconButton btn(IconData i) => t.widget<IconButton>(find.widgetWithIcon(IconButton, i));
    for (final compact in [true, false]) {
      await t.pumpWidget(MaterialApp(
          home: Scaffold(
              body: SheetOptionsPanel(
                  options: SheetOptions(sections: {...Section.values}, compact: compact), onChanged: (_) {}))));
      expect(btn(Icons.add).onPressed == null, compact);
      expect(btn(Icons.remove).onPressed == null, compact);
    }
  });

  testWidgets('Page viewer: page indicator, navigation and zoom controls', (t) async {
    final p = (await t.runAsync(png))!;
    await t.pumpWidget(MaterialApp(home: Scaffold(body: ScenePageViewer(pages: [p, p, p]))));
    expect(find.text('Page 1 of 3'), findsOneWidget);
    await t.tap(find.byTooltip('Next page'));
    await t.pump();
    expect(find.text('Page 2 of 3'), findsOneWidget);
    final iv = t.widget<InteractiveViewer>(find.byType(InteractiveViewer));
    await t.tap(find.byTooltip('Zoom In'));
    expect(iv.transformationController!.value.getMaxScaleOnAxis() > 1.2, isTrue);
    await t.tap(find.byTooltip('Fit to Screen'));
    expect(iv.transformationController!.value.getMaxScaleOnAxis(), closeTo(1.0, 1e-6));
    await t.tap(find.byTooltip('Previous page'));
    await t.pump();
    expect(find.text('Page 1 of 3'), findsOneWidget);
  });
}
