import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:scenesheet/parsers/mixer_parser.dart';
import 'package:scenesheet/parsers/scene_parser.dart';
import 'package:scenesheet/services/pdf_export_service.dart';

MixerFile fx(String p) => MixerFile(p.split('/').last, File('test/fixtures/$p').readAsBytesSync());

void main() {
  test('label keeps not-read, N/A and OFF distinct', () {
    expect(phantomLabel(true), 'ON');
    expect(phantomLabel(false), 'OFF');
    expect(phantomLabel(null), '\u2013');
    expect(phantomLabel(null, na: true), 'N/A');
    expect(phantomLabel(false, unread: true), '\u2013');
  });

  test('X32 real scene: ON and OFF come from /headamp (AES50-A 25/26 are ON)', () {
    final c = SceneParser.parse(fx('28-8.scn')).channels;
    expect(c[24].phantom, true); // ch25 -> AES50-A 25
    expect(c[25].phantom, true); // ch26 -> AES50-A 26
    expect(c[0].phantom, false);
    expect(c[23].phantom, false);
    expect(c.where((x) => x.phantom == true).length, 2);
    expect(c.every((x) => x.phantom != null), isTrue);
  });

  test('Soundcraft Ui24 real files: phantom from hw.N (OH L/R ON); unpatched inputs unavailable', () {
    for (final f in ['ui24/on_tap.json', 'ui24/template.uisnapshot']) {
      final c = SceneParser.parse(fx(f)).channels;
      Matcher on = isTrue, off = isFalse;
      expect(c[17].phantom, on); // "OH L" -> hw.17
      expect(c[18].phantom, on); // "OH R" -> hw.18
      expect(c[16].phantom, off); // "TOM 4" -> hw.16
      expect(c.where((x) => x.phantom == true).length, 2);
      expect(c.firstWhere((x) => x.id == 'P1').phantom, isNull);
      expect(c.firstWhere((x) => x.id == 'L1').phantom, isNull); // not a hw input
      expect(c.where((x) => x.physical.isEmpty).every((x) => x.phantom == null), isTrue); // src none
    }
  });

  test('Yamaha QL real file: phantom is not decoded -> unavailable, never OFF', () {
    final c = SceneParser.parse(fx('ql5/pfql_base.CLF')).channels;
    expect(c.every((x) => x.phantom == null), isTrue);
  });
}
