import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:scenesheet/models/scene_model.dart';
import 'package:scenesheet/parsers/mixer_parser.dart';
import 'package:scenesheet/parsers/scene_parser.dart';
import 'package:scenesheet/screens/help_about_screen.dart';
import 'package:scenesheet/services/app_info.dart';
import 'package:scenesheet/services/checks_service.dart';
import 'package:scenesheet/services/compare_service.dart';
import 'package:scenesheet/services/csv_export_service.dart';
import 'package:scenesheet/services/options_store.dart';
import 'package:scenesheet/services/pdf_export_service.dart';
import 'package:scenesheet/services/scene_library_service.dart';
import 'package:scenesheet/services/share_dispatch.dart';

MixerFile fx(String p) => MixerFile(p.split('/').last, File('test/fixtures/$p').readAsBytesSync());
Scene load(String p) => SceneParser.parse(fx(p));

void main() {
  final x32 = load('28-8.scn');
  final ql = load('ql5/pfql_base.CLF');
  final ui = load('ui24/on_tap.json');
  const dash = '\u2013';

  group('Data trust: known OFF vs not read vs N/A', () {
    test('stateLabel never turns a missing value into OFF', () {
      expect(stateLabel(true), 'ON');
      expect(stateLabel(true, on: '\u2713'), '\u2713');
      expect(stateLabel(false), 'OFF');
      expect(stateLabel(null), dash);
      expect(stateLabel(null, na: true), 'N/A');
      expect(stateLabel(false, unread: true), dash); // format never reads it
      expect(stateLabel(true, unread: true), dash);
    });

    test('X32 reads low-cut/gate/dyn for every channel (known values, nothing unread)', () {
      expect(x32.unread, isEmpty);
      expect(x32.channels.every((c) => c.lowcut != null && c.gate != null && c.dyn != null), isTrue);
    });

    test('QL: unread fields are declared and carry no values', () {
      expect(ql.unread,
          containsAll([DataField.lowcut, DataField.gate, DataField.dyn, DataField.insert, DataField.phantom, DataField.link, DataField.grp]));
      expect(ql.channels.every((c) => c.lowcut == null && c.gate == null && c.dyn == null && c.phantom == null), isTrue);
      expect(ql.unread.contains(DataField.physical), isFalse); // patch IS read
    });

    test('Ui24: gate/dyn/low-cut/insert unread, +48V read; line/player inputs are N/A not unknown', () {
      expect(ui.unread, {DataField.lowcut, DataField.gate, DataField.dyn, DataField.insert});
      expect(ui.channels.firstWhere((c) => c.id == 'P1').phantomNa, isTrue);
      expect(ui.channels.firstWhere((c) => c.id == 'L1').phantomNa, isTrue);
      expect(ui.channels[17].phantomNa, isFalse);
    });

    test('X32: AES50-A +48V known; Local/AES50-B mapping is declared as not verified', () {
      expect(x32.channels[24].physical, contains('AES50-A 25'));
      expect(x32.channels[24].phantom, true);
      expect(x32.notRead.any((e) => e.contains('AES50-B')), isTrue);
    });

    test('footnote explains the markers and names unread fields', () {
      final q = PdfExportService.footnote(ql);
      expect(q, contains('$dash = not read from this file'));
      expect(q, contains('Not read for this format'));
      expect(q, contains('+48V'));
      expect(PdfExportService.footnote(x32), isNot(contains('Not read for this format')));
    });
  });

  group('Import diagnostics', () {
    test('read / not-read lists exist and do not claim unread data', () {
      for (final s in [x32, ql, ui]) {
        expect(s.read, isNotEmpty);
        expect(s.notRead, isNotEmpty);
      }
      expect(ql.read.join(' '), isNot(contains('48V')));
      expect(ql.notRead.join(' '), contains('gate'));
      expect(ui.read.join(' '), contains('+48V of hardware inputs'));
    });

    test('unsupported files get guidance naming the supported formats', () {
      try {
        SceneParser.parse(MixerFile('a.bin', Uint8List.fromList([1, 2, 3])));
        fail('should throw');
      } on SceneException catch (e) {
        expect(e.message, allOf(contains('Behringer X32'), contains('Yamaha QL'), contains('Soundcraft Ui24')));
      }
    });
  });

  group('Phantom summary', () {
    test('X32 summary matches the table (only known-ON channels)', () {
      expect(phantomSummary(x32), '+48V ON: 25, 26');
      final onIds = [for (final c in x32.channels) if (phantomLabel(c.phantom, na: c.phantomNa) == 'ON') c.id];
      expect(onIds, ['25', '26']);
    });
    test('Ui24 summary and QL (not read) summary', () {
      expect(phantomSummary(ui), '+48V ON: 18, 19');
      expect(phantomSummary(ql), '+48V: not read for this format');
    });
  });

  group('CSV', () {
    test('rows mirror the channel table; unread values stay explicit', () {
      final rows = CsvExportService.rows(x32);
      expect(rows.length, 32);
      expect(rows.first.sublist(0, 2), ['01', 'Presenter']);
      expect(rows[24][3], 'ON'); // ch25 +48V
      final q = CsvExportService.csv(ql);
      expect(CsvExportService.rows(ql).first[4], dash); // low-cut never read
      expect(q.contains('OFF'), isFalse);
    });

    test('escapes commas, quotes, line breaks; UTF-8 with BOM keeps Arabic names', () {
      final s = Scene(
        mixer: 'x', model: '', name: '', version: '',
        channels: [const Strip(id: '01', name: 'غيتار, "lead"\nline')],
        buses: [], matrices: [], auxes: [], main: [], fxReturns: [], fxSlots: [],
      );
      final csv = CsvExportService.csv(s);
      expect(csv.startsWith('\uFEFF'), isTrue);
      expect(csv, contains('01,"غيتار, ""lead""\nline",,$dash,$dash,$dash,$dash,,,no'));
      // The BOM is intentional (Excel). Dart's utf8.decode drops a leading BOM, so verify it on the
      // bytes and round-trip the content that follows it.
      final bytes = utf8.encode(csv);
      expect(bytes.take(3).toList(), [0xEF, 0xBB, 0xBF]);
      expect(csv.substring(1), startsWith('ch,name,physical,+48V,'));
      expect(utf8.decode(bytes.sublist(3)), csv.substring(1));
    });
  });

  group('Pre-show checks', () {
    test('X32 fixture: unnamed +48V channels and the shared input are reported', () {
      final items = ChecksService.run(x32);
      final unnamed = items.firstWhere((i) => i.title.contains('unnamed'));
      expect(unnamed.level, CheckLevel.warning);
      expect(unnamed.channels, ['25', '26']);
      final dup = items.firstWhere((i) => i.title.contains('Same input'));
      expect(dup.level, CheckLevel.info); // possible concern, not an error
      expect(dup.channels, ['16', '17', '19']);
      // channels 01/02 share source 1 but are a linked pair -> not reported
      expect(items.any((i) => i.channels.contains('01')), isFalse);
      expect(items.any((i) => i.title.contains('without an input')), isFalse);
    });
    test('QL: unread fields reported, no phantom claims', () {
      final items = ChecksService.run(ql);
      expect(items.any((i) => i.title == 'Not read for this format'), isTrue);
      expect(items.any((i) => i.level == CheckLevel.warning), isFalse);
    });
  });

  group('Input List', () {
    test('sorted by input socket, ties by channel', () {
      final o = PdfExportService.inputListOrder(x32);
      expect(o.length, 32);
      expect(o.take(2).map((c) => c.id), ['01', '02']);
      for (var i = 1; i < o.length; i++) {
        expect(o[i - 1].portRank! <= o[i].portRank!, isTrue);
      }
    });
    test('every channel appears once; each page holds one complete table', () {
      final o = SheetOptions(sections: {...Section.values}, inputList: true);
      final p = PdfExportService.plan(ql, o);
      expect(p.pages.length >= 2, isTrue);
      expect(p.pages.every((pg) => pg.length == 1 && pg.first.title.startsWith('Input List')), isTrue);
      expect(p.pages.fold<int>(0, (a, pg) => a + pg.first.rows), 64);
    });
    test('channels without a reported socket are listed separately, not given a socket', () {
      final p = PdfExportService.plan(ui, SheetOptions(sections: {...Section.values}, inputList: true));
      final titles = [for (final pg in p.pages) pg.first.title];
      expect(titles.any((t) => t.contains('socket not reported')), isTrue);
      expect(p.pages.fold<int>(0, (a, pg) => a + pg.first.rows), 28);
    });
  });

  group('Compare scenes', () {
    test('same scene: no differences, scope stated, never "identical"', () {
      final r = CompareService.compare(x32, x32);
      expect(r.diffs, isEmpty);
      expect(r.compared, containsAll(['channel names', 'patch / source', '+48V', 'groups']));
      expect(r.summary, startsWith('No differences found in the compared fields.'));
      expect(r.summary.toLowerCase(), isNot(contains('identical')));
    });
    test('QL name change is found; unread categories are excluded, not compared', () {
      final r = CompareService.compare(ql, load('ql5/pfql_name.CLF'));
      expect(r.diffs.length, 1);
      expect([r.diffs[0].channel, r.diffs[0].field, r.diffs[0].a, r.diffs[0].b], ['08', 'name', 'ch 8', 'ZZTOP']);
      expect(r.excluded.join(' '), allOf(contains('+48V'), contains('groups')));
      expect(r.summary, contains('Not compared'));
    });
    test('QL patch changes are found', () {
      final r = CompareService.compare(ql, load('ql5/pfql_mod3.CLF'));
      expect(r.diffs.map((d) => '${d.channel}:${d.a}>${d.b}'), ['04:INPUT 4>DANTE 1', '12:INPUT 12>DANTE 2']);
    });
    test('different mixer families: only names compared', () {
      final r = CompareService.compare(x32, ql);
      expect(r.diffs.every((d) => d.field == 'name'), isTrue);
      expect(r.excluded.join(' '), contains('different mixer formats'));
    });
    test('Ui24 JSON vs snapshot of the same show: no differences, groups compared', () {
      final r = CompareService.compare(ui, load('ui24/template.uisnapshot'));
      expect(r.diffs, isEmpty);
      expect(r.compared, contains('groups'));
    });
  });

  group('Sharing choices', () {
    final calls = <String>[];
    ShareActions fake() => ShareActions(
          pdf: (b, base) async => calls.add('pdf:$base:${b.length}'),
          png: (pages, base, {int? only}) async => calls.add('png:$base:${pages.length}:$only'),
          csv: (c, base) async => calls.add('csv:$base:${c.startsWith('\uFEFF')}'),
        );
    final pages = [Uint8List(1), Uint8List(2), Uint8List(3)];
    Future<void> run(ShareChoice c, {List<Uint8List>? pg, int cur = 0}) => dispatchShare(c,
        scene: x32, pdf: Uint8List(9), pages: pg ?? pages, base: 'b', currentPage: cur, actions: fake());
    setUp(calls.clear);

    test('PDF choice calls only the PDF method', () async {
      await run(ShareChoice.pdf);
      expect(calls, ['pdf:b:9']);
    });
    test('current-page PNG sends the selected page index only', () async {
      await run(ShareChoice.pngCurrent, cur: 1);
      expect(calls, ['png:b:3:1']);
      calls.clear();
      await run(ShareChoice.pngCurrent, pg: [Uint8List(1)]);
      expect(calls, ['png:b:1:null']);
    });
    test('all-pages PNG sends every page', () async {
      await run(ShareChoice.pngAll);
      expect(calls, ['png:b:3:null']);
    });
    test('CSV choice calls only the CSV method', () async {
      await run(ShareChoice.csv);
      expect(calls, ['csv:b:true']);
    });
  });

  group('Options and library behaviour', () {
    test('options persist, sanitize to what the scene has, never end up empty', () async {
      final dir = Directory.systemTemp.createTempSync('opts');
      addTearDown(() => dir.deleteSync(recursive: true));
      final store = OptionsStore(dir);
      expect(await store.load(), isNull);
      final saved = SheetOptions(sections: {Section.bus, Section.matrix}, format: OutputFormat.a3, compact: true, textScale: 1.2);
      await store.save(saved);
      final back = (await store.load())!;
      expect([back.format, back.compact, back.textScale, back.sections], [OutputFormat.a3, true, 1.2, saved.sections]);
      // QL has channels only: saved Bus/Matrix are dropped and the selection falls back to what exists
      expect(back.sanitizedFor(ql).sections, {Section.channel});
      expect(SheetOptions.fromJson('garbage'), isNull);
    });

    test('peek (used by Compare) does not change Last Opened; open does', () async {
      final tmp = Directory.systemTemp.createTempSync('peek');
      addTearDown(() => tmp.deleteSync(recursive: true));
      var t = 0;
      final lib = SceneLibrary(Directory('${tmp.path}/s'), now: () => DateTime(2026).add(Duration(minutes: t++)));
      final a = await lib.add(MixerFile('a.scn', fx('28-8.scn').bytes));
      await lib.add(MixerFile('b.CLF', fx('ql5/pfql_base.CLF').bytes));
      await lib.peek(a);
      expect((await lib.list()).first.name, 'b.CLF');
      await lib.open(a);
      expect((await lib.list()).first.name, 'a.scn');
    });
  });

  group('Project configuration', () {
    final wf = File('ci/build.yml').readAsStringSync();
    test('workflow: label, build number, blocking tests, single file_picker pin', () {
      expect(wf, contains('android:label="SceneSheet"'));
      expect(wf, contains(r'--build-number=$BUILD_NUMBER'));
      expect(wf, contains('flutter test'));
      expect(wf, isNot(contains('continue-on-error')));
      expect(wf, isNot(contains('pub add file_picker')));
      expect(wf, contains('workflow_dispatch'));
      expect(wf, contains('scenesheet-apk'));
    });
    test('pubspec: development version, one file_picker constraint, icon assets present', () {
      final p = File('pubspec.yaml').readAsStringSync();
      expect(p, contains('version: 0.8.0+1'));
      expect(p, contains('file_picker: ^10.3.6'));
      expect(File('design/android_res/mipmap-anydpi-v26/ic_launcher.xml').existsSync(), isTrue);
      expect(wf, contains('design/android_res'));
    });
  });

  testWidgets('Help & About lists the implemented features and shows version + build', (t) async {
    AppInfo.resetForTest();
    PackageInfo.setMockInitialValues(appName: 'SceneSheet', packageName: 'x.y', version: '0.8.0', buildNumber: '7', buildSignature: '');
    await t.pumpWidget(const MaterialApp(home: HelpAboutScreen()));
    await t.pumpAndSettle();
    expect(find.text('Version 0.8.0 (build 7)'), findsOneWidget);
    // The help list is a lazy ListView: scroll each entry into view before checking it exists.
    for (final title in ['Data markers (\u2713, OFF, \u2013, N/A)', 'CSV and Input List', 'Pre-show checks and Compare scenes']) {
      await t.scrollUntilVisible(find.text(title), 300, scrollable: find.byType(Scrollable).first);
      expect(find.text(title), findsOneWidget);
    }
  });
}
