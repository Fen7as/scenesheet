Real files written by the vendors' own tools (MIT-licensed test data from the repos below).
- ql5/*.CLF: QL Editor V5.8.1.27 files from https://github.com/stoatworks-labs/songbook (MIT).
  pfql_name = CH8 renamed ZZTOP; pfql_mod3 = CH4 -> DANTE1, CH12 -> DANTE2.
- ui24/on_tap.json (Ui24R offline export) and ui24/template.uisnapshot (USB show snapshot)
  from https://github.com/HighTechHarmony/SoundcraftUiSC (MIT).
- 28-8.scn: user-supplied X32 scene.
