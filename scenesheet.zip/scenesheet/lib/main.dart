import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(const SceneSheetApp());

class SceneSheetApp extends StatelessWidget {
  const SceneSheetApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'SceneSheet',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFF5C6190), useMaterial3: true),
        home: const HomeScreen(),
      );
}
