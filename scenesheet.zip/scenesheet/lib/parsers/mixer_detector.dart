import 'mixer_parser.dart';
import 'x32_parser.dart';

class MixerDetector {
  static final List<MixerParser> _parsers = [X32Parser()];
  static MixerParser? detect(String text) {
    for (final p in _parsers) {
      if (p.matches(text)) return p;
    }
    return null;
  }
}
