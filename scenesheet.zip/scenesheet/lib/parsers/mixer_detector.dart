import 'mixer_parser.dart';
import 'soundcraft_parser.dart';
import 'x32_parser.dart';
import 'yamaha_parser.dart';

class MixerDetector {
  /// Order matters: strict content matches first, detect-only fallbacks last.
  static final List<MixerParser> parsers = [
    X32Parser(),
    YamahaQlParser(),
    YamahaClParser(),
    ...SoundcraftParser.all(),
  ];

  static MixerParser? detect(MixerFile f) {
    for (final p in parsers) {
      if (p.matches(f)) return p;
    }
    return null;
  }

  /// Choices for the manual fallback picker.
  static List<MixerParser> get manualChoices =>
      [parsers[0], parsers[1], parsers[2], parsers[3], parsers.last];
}
