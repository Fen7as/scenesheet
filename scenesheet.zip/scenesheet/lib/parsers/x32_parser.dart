import '../models/scene_model.dart';
import 'mixer_parser.dart';

class _Phys {
  final String text;
  final bool? phantom;
  const _Phys(this.text, [this.phantom]);
}

/// Behringer X32 / Midas M32 text scene (.scn, header "#4.0#").
class X32Parser implements MixerParser {
  Map<String, List<String>> _d = {};
  static final _tokRe = RegExp(r'"[^"]*"|\S+');

  @override
  bool matches(String t) =>
      RegExp(r'^#\d+\.\d+#').hasMatch(t) && t.contains('\n/ch/01/config') && t.contains('\n/config/chlink');

  List<String> _tok(String l) => _tokRe.allMatches(l).map((m) {
        final s = m[0]!;
        return s.startsWith('"') ? s.substring(1, s.length - 1) : s;
      }).toList();
  List<String> _g(String p) => _d[p] ?? const [];
  String _s(List<String> t, int i) => i < t.length ? t[i] : '';
  bool _on(List<String> t, int i) => _s(t, i) == 'ON';
  String _n(int n) => n.toString().padLeft(2, '0');

  int _lk(List<String> l, int n) {
    final p = (n - 1) ~/ 2;
    return (p < l.length && l[p] == 'ON') ? (n.isOdd ? 1 : 2) : 0;
  }

  String _grp(List<String> t) {
    String bits(String s) => s.startsWith('%') ? s.substring(1) : s;
    final o = <String>[];
    final a = bits(_s(t, 0)), b = bits(_s(t, 1));
    for (var i = 0; i < a.length; i++) {
      if (a[i] == '1') o.add('D${a.length - i}');
    }
    for (var i = 0; i < b.length; i++) {
      if (b[i] == '1') o.add('M${b.length - i}');
    }
    return o.join(' ');
  }

  bool? _phantom(int headampIdx) {
    final h = _g('/headamp/${headampIdx.toString().padLeft(3, '0')}');
    return h.isEmpty ? null : _s(h, 1) == 'ON';
  }

  _Phys _phys(int s) {
    if (s <= 0) return const _Phys('');
    if (s >= 39 && s <= 40) return _Phys('$s: USB-Player ${s == 39 ? 'L' : 'R'}');
    if (s > 40) return _Phys('src $s');
    final inr = _g('/config/routing/IN');
    final blk = s <= 32 ? (s - 1) ~/ 8 : 4;
    final tok = _s(inr, blk);
    if (s > 36 || tok.startsWith('AUX')) return _Phys('$s: Aux In ${s - 32}');
    final m = RegExp(r'^(A|B|CARD|UIN|L?)(\d+)-(\d+)$').firstMatch(tok);
    if (m == null) return _Phys('$s: $tok');
    final pre = m[1]!;
    final num = int.parse(m[2]!) + (s <= 32 ? (s - 1) % 8 : s - 33);
    switch (pre) {
      case 'A':
        return _Phys('$s: AES50-A $num', _phantom(32 + num - 1));
      case 'B':
        return _Phys('$s: AES50-B $num', _phantom(80 + num - 1));
      case 'CARD':
        return _Phys('$s: Card $num');
      case 'UIN':
        return _Phys('$s: User In $num');
      default:
        return _Phys('$s: Local $num', _phantom(num - 1));
    }
  }

  Strip _ins(String id, String base, String name, String color, int link) {
    final ins = _g('$base/insert');
    final dyn = _g('$base/dyn');
    return Strip(
      id: id,
      name: name,
      color: color,
      link: link,
      dyn: dyn.isEmpty ? null : _on(dyn, 0),
      insert: _s(ins, 2),
      insertOn: _on(ins, 0),
    );
  }

  @override
  Scene parse(String text) {
    _d = {};
    var ver = '', name = '', first = true;
    for (final raw in text.split('\n')) {
      final l = raw.trim();
      if (l.isEmpty) continue;
      final t = _tok(l);
      if (first) {
        first = false;
        ver = t[0].replaceAll('#', '');
        name = t.length > 1 ? t[1] : '';
        continue;
      }
      if (l.startsWith('/')) _d[t[0]] = t.sublist(1);
    }

    final ch = <Strip>[], bus = <Strip>[], mtx = <Strip>[], aux = <Strip>[];
    final fr = <Strip>[], fs = <Strip>[], main = <Strip>[];
    final chl = _g('/config/chlink');

    for (var n = 1; n <= 32; n++) {
      final b = '/ch/${_n(n)}';
      final c = _g('$b/config');
      if (c.isEmpty) continue;
      final p = _phys(int.tryParse(_s(c, 3)) ?? 0);
      final ins = _g('$b/insert');
      ch.add(Strip(
        id: _n(n), name: _s(c, 0), color: _s(c, 2), link: _lk(chl, n),
        lowcut: _on(_g('$b/preamp'), 2), gate: _on(_g('$b/gate'), 0), dyn: _on(_g('$b/dyn'), 0),
        phantom: p.phantom, insert: _s(ins, 2), insertOn: _on(ins, 0),
        physical: p.text, grp: _grp(_g('$b/grp')),
      ));
    }
    for (var n = 1; n <= 16; n++) {
      final b = '/bus/${_n(n)}', c = _g('$b/config');
      if (c.isNotEmpty) bus.add(_ins(_n(n), b, _s(c, 0), _s(c, 2), _lk(_g('/config/buslink'), n)));
    }
    for (var n = 1; n <= 6; n++) {
      final b = '/mtx/${_n(n)}', c = _g('$b/config');
      if (c.isNotEmpty) mtx.add(_ins(_n(n), b, _s(c, 0), _s(c, 2), _lk(_g('/config/mtxlink'), n)));
    }
    for (var n = 1; n <= 8; n++) {
      final c = _g('/auxin/${_n(n)}/config');
      if (c.isEmpty) continue;
      aux.add(Strip(
        id: _n(n), name: _s(c, 0), color: _s(c, 2), link: _lk(_g('/config/auxlink'), n),
        physical: _phys(int.tryParse(_s(c, 3)) ?? 0).text,
      ));
    }
    for (var n = 1; n <= 8; n++) {
      final c = _g('/fxrtn/${_n(n)}/config');
      if (c.isEmpty) continue;
      final slot = (n + 1) ~/ 2;
      final src = _g('/fx/$slot/source');
      fr.add(Strip(
        id: 'FX$slot${n.isOdd ? 'L' : 'R'}', name: _s(c, 0), color: _s(c, 2),
        link: _lk(_g('/config/fxlink'), n),
        device: _s(_g('/fx/$slot'), 0),
        src: src.isEmpty ? 'INS' : _s(src, (n - 1) % 2),
      ));
    }
    for (var s = 5; s <= 8; s++) {
      final dev = _s(_g('/fx/$s'), 0);
      if (dev.isEmpty) continue;
      final src = _g('/fx/$s/source');
      fs.add(Strip(id: 'FX$s', device: dev, src: src.isEmpty ? 'INS' : _s(src, 0)));
    }
    for (final m in const [['LR', '/main/st'], ['M', '/main/m']]) {
      if (_g('${m[1]}/config').isEmpty) continue;
      main.add(_ins(m[0], m[1], m[0], 'OFF', 0));
    }

    return Scene(
      mixer: 'Behringer X32 / Midas M32 family',
      model: 'X32/M32 (scene format $ver)',
      name: name, version: ver,
      channels: ch, buses: bus, matrices: mtx, auxes: aux,
      main: main, fxReturns: fr, fxSlots: fs,
    );
  }
}
