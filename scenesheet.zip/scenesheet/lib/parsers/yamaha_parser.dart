import 'dart:convert';
import '../models/scene_model.dart';
import 'mixer_parser.dart';

/// Yamaha CL/QL `.CLF`. Identified by the product string at 0x10 ("QL [OSX, 5.8.1.27]").
/// Layout reference: stoatworks-labs/songbook (MIT), located by diffing real QL Editor files.
abstract class YamahaParser implements MixerParser {
  static const productAt = 0x10;
  String get series; // 'QL' or 'CL'

  static String? product(MixerFile f) {
    final b = f.bytes;
    if (b.length < productAt + 32) return null;
    final s = b.sublist(productAt, productAt + 32);
    final end = s.indexOf(0);
    final t = latin1.decode(end < 0 ? s : s.sublist(0, end)).trim();
    return (t.startsWith('QL ') || t.startsWith('CL ')) ? t : null;
  }

  @override
  bool matches(MixerFile f) => product(f)?.startsWith('$series ') ?? false;
}

/// REAL parser. Decoded from the file: product/editor build, 64 input-channel names
/// (max 8 chars) and input patch (INPUT n / DANTE n). Everything else in the CLF
/// (head amps, phantom, HPF, gate, dynamics, inserts, DCA, mute groups, sends,
/// buses, matrix, main, FX, scene memory) is NOT decoded yet and is left empty.
class YamahaQlParser extends YamahaParser {
  static const _patchAt = 0x00d74b, _nameAt = 0x00d858, _n = 64, _slots = 96, _chunk = 4, _blocks = 2;
  @override
  String get series => 'QL';
  @override
  String get label => 'Yamaha QL series (.CLF)';

  /// '' = unpatched (code 0), kNotRead = unknown code, otherwise the port.
  static String _patch(int v) {
    if (v == 0) return '';
    if (v >= 0x01 && v <= 0x40) return 'DANTE $v';
    if (v >= 0x41 && v <= 0x48) return 'INPUT ${v - 0x40}';
    if (v >= 0xC1 && v <= 0xD8) return 'INPUT ${v - 0xC0 + 8}';
    return kNotRead;
  }

  static int? _rank(int v) {
    if (v >= 0x01 && v <= 0x40) return 200 + v;
    if (v >= 0x41 && v <= 0x48) return 100 + v - 0x40;
    if (v >= 0xC1 && v <= 0xD8) return 100 + v - 0xC0 + 8;
    return null;
  }

  @override
  Scene parse(MixerFile f) {
    final d = f.bytes;
    final prod = YamahaParser.product(f)!;
    if (d.length < _nameAt + _blocks * _slots * _chunk) {
      throw SceneException('Could not read this mixer file.');
    }
    var decoded = 0;
    for (var i = 0; i < _n; i++) {
      final p = _patch(d[_patchAt + i]);
      if (p.isNotEmpty && p != kNotRead) decoded++;
    }
    // Offset was established on QL Editor 5.8.1 files; refuse to guess otherwise.
    if (decoded * 4 < _n * 3) throw SceneException('Could not read this mixer file.');
    final ch = <Strip>[];
    for (var i = 0; i < _n; i++) {
      final raw = <int>[];
      for (var b = 0; b < _blocks; b++) {
        final at = _nameAt + b * _slots * _chunk + i * _chunk;
        raw.addAll(d.sublist(at, at + _chunk));
      }
      final end = raw.indexOf(0);
      final name = latin1.decode(end < 0 ? raw : raw.sublist(0, end)).trim();
      ch.add(Strip(
        id: (i + 1).toString().padLeft(2, '0'),
        name: name,
        physical: _patch(d[_patchAt + i]),
        portRank: _rank(d[_patchAt + i]),
      ));
    }
    return Scene(
      mixer: 'Yamaha QL series',
      model: prod,
      name: f.name.replaceFirst(RegExp(r'\.[^.]*$'), ''),
      version: prod,
      channels: ch, buses: [], matrices: [], auxes: [], main: [], fxReturns: [], fxSlots: [],
      unread: const {
        DataField.lowcut, DataField.gate, DataField.dyn, DataField.insert,
        DataField.phantom, DataField.link, DataField.grp,
      },
      read: const ['Channel names (up to 8 characters)', 'Input patch (INPUT / DANTE ports)'],
      notRead: const [
        '+48V, HPF, gate, dynamics, inserts',
        'Channel links, DCA and mute groups',
        'Buses, matrix, main, FX and scene memory',
      ],
    );
  }
}

/// Detected only: no real CL file was available, so the CL layout is unverified.
class YamahaClParser extends YamahaParser {
  @override
  String get series => 'CL';
  @override
  String get label => 'Yamaha CL series (.CLF)';
  @override
  Scene parse(MixerFile f) =>
      throw SceneException('Yamaha CL detected, but this file format is not supported yet.');
}
