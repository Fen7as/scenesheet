import 'dart:convert';
import '../models/scene_model.dart';
import 'mixer_parser.dart';

const _unsupported = 'Soundcraft file format detected, but this format is not supported yet.';

/// REAL parser for Soundcraft Ui24-series data: the offline JSON export and the USB
/// `.uisnapshot` (both are flat dotted keys: i.N.name, i.N.src, ...).
/// Reference: HighTechHarmony/SoundcraftUiSC (MIT) + its real example exports.
/// Not decoded (no reliable meaning in the samples): colours, gate/dyn on-off, HPF
/// state, matrix, insert.
class SoundcraftUiParser implements MixerParser {
  @override
  String get label => 'Soundcraft Ui (Ui24 JSON / .uisnapshot)';

  static final _snapIn = RegExp(r'(^|\n)i\.0\.name=');
  static final _snapSub = RegExp(r'(^|\n)s\.0\.name=');

  @override
  bool matches(MixerFile f) {
    final t = f.text;
    final s = t.trimLeft();
    if (s.startsWith('{')) {
      return s.contains('"i.0.name"') && s.contains('"schema"') && s.contains('"firmware"');
    }
    return _snapIn.hasMatch(t) && _snapSub.hasMatch(t);
  }

  Map<String, String> _flat(MixerFile f) {
    final t = f.text.trimLeft();
    final m = <String, String>{};
    if (t.startsWith('{')) {
      final j = jsonDecode(t);
      if (j is! Map) throw SceneException('Could not read this mixer file.');
      j.forEach((k, v) {
        if (v is! Map && v is! List) m['$k'] = '$v';
      });
    } else {
      for (final raw in t.split('\n')) {
        final line = raw.trim();
        if (line.isEmpty || line.startsWith('#')) continue;
        final i = line.indexOf('=');
        if (i > 0) m[line.substring(0, i)] = line.substring(i + 1).trim();
      }
    }
    return m;
  }

  @override
  Scene parse(MixerFile f) {
    final m = _flat(f);
    String two(int n) => n.toString().padLeft(2, '0');
    int count(String p) {
      var n = 0;
      while (m.containsKey('$p.$n.name')) {
        n++;
      }
      return n;
    }

    int link(String p) {
      final s = int.tryParse(m['$p.stereoIndex'] ?? '');
      return s == 0 ? 1 : (s == 1 ? 2 : 0);
    }

    String grp(String p) {
      final o = <String>[];
      final v = int.tryParse(m['$p.vca'] ?? '') ?? -1;
      if (v >= 0) o.add('V${v + 1}');
      final mg = int.tryParse(m['$p.mgmask'] ?? '') ?? 0;
      for (var k = 0; k < 6; k++) {
        if ((mg >> k) & 1 == 1) o.add('M${k + 1}');
      }
      final sg = int.tryParse(m['$p.subgroup'] ?? '') ?? -1;
      if (sg >= 0) o.add('S${sg + 1}');
      return o.join(' ');
    }

    String phys(String p) {
      final s = m['$p.src'] ?? '';
      if (s.isEmpty || s == 'none') return '';
      final h = RegExp(r'^hw\.(\d+)$').firstMatch(s);
      return h != null ? 'Input ${int.parse(h[1]!) + 1}' : s;
    }

    final ch = <Strip>[];
    void add(String key, String prefix) {
      for (var n = 0; n < count(key); n++) {
        final p = '$key.$n';
        ch.add(Strip(
          id: prefix.isEmpty ? two(n + 1) : '$prefix${n + 1}',
          name: m['$p.name'] ?? '',
          link: link(p),
          phantom: key == 'i' && m.containsKey('$p.phantom') ? m['$p.phantom'] == '1' : null,
          physical: phys(p),
          grp: grp(p),
        ));
      }
    }

    add('i', '');
    add('l', 'L');
    add('p', 'P');

    final bus = [
      for (var n = 0; n < count('s'); n++) Strip(id: two(n + 1), name: m['s.$n.name'] ?? '', link: link('s.$n')),
    ];
    final aux = [
      for (var n = 0; n < count('a'); n++) Strip(id: two(n + 1), name: m['a.$n.name'] ?? '', link: link('a.$n')),
    ];
    final fx = [
      for (var n = 0; n < count('f'); n++)
        Strip(
          id: 'FX${n + 1}',
          name: m['f.$n.name'] ?? '',
          device: m.containsKey('f.$n.fxtype') ? 'type ${m['f.$n.fxtype']}' : '',
        ),
    ];
    final main = m.containsKey('m.name') ? [Strip(id: 'M', name: m['m.name'] ?? '')] : <Strip>[];

    return Scene(
      mixer: 'Soundcraft Ui',
      model: [m['model'], m['firmware']].where((e) => e != null && e.isNotEmpty).join(' fw '),
      name: f.name.replaceFirst(RegExp(r'\.[^.]*$'), ''),
      version: m['schema'] ?? '',
      channels: ch, buses: bus, matrices: [], auxes: aux, main: main, fxReturns: fx, fxSlots: [],
      fxStereo: false,
    );
  }
}

/// Detected only (no real sample/format reference): other Soundcraft families.
class SoundcraftParser implements MixerParser {
  final String family; // '' = generic
  final RegExp? pattern;
  SoundcraftParser(this.family, [this.pattern]);

  @override
  String get label => family.isEmpty ? 'Soundcraft (other)' : 'Soundcraft $family';

  @override
  bool matches(MixerFile f) {
    if (!f.head.toLowerCase().contains('soundcraft')) return false;
    return pattern == null || pattern!.hasMatch(f.head);
  }

  @override
  Scene parse(MixerFile f) => throw SceneException(_unsupported);

  /// Real Ui parser first, then detect-only adapters for the other families.
  static List<MixerParser> all() => [
        SoundcraftUiParser(),
        SoundcraftParser('Si', RegExp(r'\bSi (Impact|Expression|Performer)\b|\bSi[123]\b')),
        SoundcraftParser('Vi', RegExp(r'\bVi\d{3,4}\b')),
        SoundcraftParser(''),
      ];
}
