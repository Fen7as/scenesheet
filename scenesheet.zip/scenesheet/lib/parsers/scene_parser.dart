import '../models/scene_model.dart';
import 'mixer_detector.dart';
import 'mixer_parser.dart';

class SceneParser {
  static Scene parse(String text, String fileName) {
    final t = text.replaceAll('\r', '').trimLeft();
    if (t.isEmpty) throw SceneException('The file is empty.');
    final p = MixerDetector.detect(t);
    if (p == null) {
      throw SceneException('Unsupported file. Only Behringer X32 / Midas M32 .scn scene files are supported.');
    }
    final Scene s;
    try {
      s = p.parse(t);
    } catch (_) {
      throw SceneException('The scene file is corrupted or incomplete.');
    }
    if (s.channels.isEmpty) throw SceneException('The scene contains no channels.');
    s.fileName = fileName;
    return s;
  }
}
