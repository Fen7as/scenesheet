import '../models/scene_model.dart';
import 'mixer_detector.dart';
import 'mixer_parser.dart';

class SceneParser {
  static Scene parse(MixerFile f, {MixerParser? force}) {
    if (f.bytes.isEmpty) throw SceneException('The file is empty.');
    final p = force ?? MixerDetector.detect(f);
    if (p == null) throw SceneException('Unsupported mixer file format.');
    final Scene s;
    try {
      s = p.parse(f);
    } on SceneException {
      rethrow;
    } catch (_) {
      throw SceneException('Could not read this mixer file.');
    }
    if (s.channels.isEmpty) throw SceneException('The scene contains no channels.');
    s.fileName = f.name;
    return s;
  }
}
