import '../models/scene_model.dart';

class SceneException implements Exception {
  final String message;
  SceneException(this.message);
  @override
  String toString() => message;
}

abstract class MixerParser {
  bool matches(String text);
  Scene parse(String text);
}
