import 'dart:convert';
import 'dart:typed_data';
import '../models/scene_model.dart';

class SceneException implements Exception {
  final String message;
  SceneException(this.message);
  @override
  String toString() => message;
}

/// Raw imported file; parsers inspect bytes/text as needed.
class MixerFile {
  final String name;
  final Uint8List bytes;
  MixerFile(this.name, this.bytes);
  String get ext => name.contains('.') ? name.split('.').last.toLowerCase() : '';
  late final String text = utf8.decode(bytes, allowMalformed: true);
  /// First 64 KB as Latin-1 (safe for binary files) for signature scans.
  late final String head = latin1.decode(bytes.length > 65536 ? bytes.sublist(0, 65536) : bytes);
}

abstract class MixerParser {
  /// Label shown in the manual mixer picker.
  String get label;
  /// True when the file contents/extension identify this mixer family.
  bool matches(MixerFile f);
  /// Throws [SceneException] for unsupported/corrupt files.
  Scene parse(MixerFile f);
}
