import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/scene_model.dart';

/// Remembers the last-used Scene Sheet options (small JSON file in app storage).
class OptionsStore {
  final File file;
  OptionsStore(Directory dir) : file = File('${dir.path}/options.json');
  static Future<OptionsStore> app() async => OptionsStore(await getApplicationDocumentsDirectory());

  Future<SheetOptions?> load() async {
    try {
      if (!await file.exists()) return null;
      return SheetOptions.fromJson(jsonDecode(await file.readAsString()));
    } catch (_) {
      return null;
    }
  }

  Future<void> save(SheetOptions o) async {
    try {
      await file.writeAsString(jsonEncode(o.toJson()), flush: true);
    } catch (_) {/* best effort */}
  }
}
