import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';
import '../parsers/mixer_parser.dart';

class LibraryEntry {
  final String id, name;
  final DateTime lastOpened;
  const LibraryEntry(this.id, this.name, this.lastOpened);
  LibraryEntry touched(DateTime t) => LibraryEntry(id, name, t);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'opened': lastOpened.millisecondsSinceEpoch};
  static LibraryEntry fromJson(Map<String, dynamic> j) =>
      LibraryEntry(j['id'] as String, j['name'] as String, DateTime.fromMillisecondsSinceEpoch(j['opened'] as int));
}

/// App-private scene store: <root>/<id>/<original file name> + <root>/index.json
/// (id, name, last opened only). The stored file is the source of truth; the original
/// external file is never read again, modified or deleted.
class SceneLibrary {
  final Directory root;
  final DateTime Function() now;
  static int _seq = 0;
  SceneLibrary(this.root, {DateTime Function()? now}) : now = now ?? DateTime.now;

  static Future<SceneLibrary> app() async =>
      SceneLibrary(Directory('${(await getApplicationDocumentsDirectory()).path}/scenes'));

  File get _index => File('${root.path}/index.json');
  File fileOf(LibraryEntry e) => File('${root.path}/${e.id}/${e.name}');
  static String _safe(String n) {
    final s = n.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();
    return s.isEmpty ? 'scene' : s;
  }

  Future<List<LibraryEntry>> _read() async {
    try {
      if (await _index.exists()) {
        final j = jsonDecode(await _index.readAsString()) as List;
        return [for (final e in j) LibraryEntry.fromJson(e as Map<String, dynamic>)];
      }
    } catch (_) {/* fall through to rebuild */}
    return _rebuild();
  }

  /// Index lost/corrupt: recover from the stored files themselves.
  Future<List<LibraryEntry>> _rebuild() async {
    final out = <LibraryEntry>[];
    if (!await root.exists()) return out;
    await for (final d in root.list()) {
      if (d is! Directory) continue;
      await for (final f in d.list()) {
        if (f is File) {
          out.add(LibraryEntry(d.uri.pathSegments.where((s) => s.isNotEmpty).last,
              f.uri.pathSegments.last, await f.lastModified()));
        }
      }
    }
    return out;
  }

  Future<void> _write(List<LibraryEntry> l) async {
    await root.create(recursive: true);
    final tmp = File('${_index.path}.tmp');
    await tmp.writeAsString(jsonEncode([for (final e in l) e.toJson()]), flush: true);
    await tmp.rename(_index.path);
  }

  /// Most recently opened first.
  Future<List<LibraryEntry>> list() async {
    final l = (await _read()).where((e) => fileOf(e).existsSync()).toList();
    l.sort((a, b) => b.lastOpened.compareTo(a.lastOpened));
    return l;
  }

  static bool _same(Uint8List a, Uint8List b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  Future<LibraryEntry> _touch(List<LibraryEntry> l, LibraryEntry e) async {
    final t = e.touched(now());
    await _write([for (final x in l) x.id == e.id ? t : x]);
    return t;
  }

  /// Copies the imported bytes into app storage (re-importing identical content reuses the entry).
  Future<LibraryEntry> add(MixerFile f) async {
    final l = await _read();
    final name = _safe(f.name);
    for (final e in l) {
      final file = fileOf(e);
      if (e.name == name && file.existsSync() && _same(await file.readAsBytes(), f.bytes)) {
        return _touch(l, e);
      }
    }
    final id = '${now().microsecondsSinceEpoch}_${_seq++}';
    final e = LibraryEntry(id, name, now());
    await Directory('${root.path}/$id').create(recursive: true);
    await fileOf(e).writeAsBytes(f.bytes, flush: true);
    await _write([...l, e]);
    return e;
  }

  /// Reads the STORED copy and updates Last Opened.
  Future<MixerFile> open(LibraryEntry e) async {
    final file = fileOf(e);
    if (!await file.exists()) throw SceneException('This scene is no longer available.');
    final bytes = await file.readAsBytes();
    await _touch(await _read(), e);
    return MixerFile(e.name, bytes);
  }

  /// Deletes only the app-owned copy.
  Future<void> delete(LibraryEntry e) async {
    final d = Directory('${root.path}/${e.id}');
    if (await d.exists()) await d.delete(recursive: true);
    await _write([for (final x in await _read()) if (x.id != e.id) x]);
  }
}
