import '../models/scene_model.dart';
import 'pdf_export_service.dart' show phantomLabel;

class DiffItem {
  final String channel, field, a, b;
  const DiffItem(this.channel, this.field, this.a, this.b);
}

class CompareResult {
  final String nameA, nameB;
  final List<String> compared, excluded, onlyInA, onlyInB;
  final List<DiffItem> diffs;
  /// Values skipped because one side was not read (never counted as a change).
  final int notComparable;
  const CompareResult(this.nameA, this.nameB, this.compared, this.excluded, this.diffs, this.onlyInA, this.onlyInB,
      this.notComparable);

  String get summary {
    final head = diffs.isNotEmpty
        ? '${diffs.length} difference(s) found.'
        : (excluded.isEmpty && notComparable == 0
            ? 'No differences found in the compared fields.'
            : 'No differences found in the fields that could be compared.');
    final ex = excluded.isEmpty ? '' : ' Not compared: ${excluded.join('; ')}.';
    final nc = notComparable == 0 ? '' : ' $notComparable value(s) were skipped because one side was not read.';
    return '$head Compared: ${compared.join(', ')}.$ex$nc';
  }
}

/// Read-only comparison of channel names, patch, +48V and groups (only where both files expose them).
class CompareService {
  static String nameOf(Scene s) => s.name.isEmpty ? s.fileName : s.name;

  static CompareResult compare(Scene a, Scene b) {
    final same = a.mixer == b.mixer;
    final compared = <String>['channel names'];
    final excluded = <String>[];
    bool can(DataField f, String what) {
      if (!same) {
        excluded.add('$what (different mixer formats)');
        return false;
      }
      if (a.unread.contains(f) || b.unread.contains(f)) {
        excluded.add('$what (not read from ${a.unread.contains(f) ? nameOf(a) : nameOf(b)})');
        return false;
      }
      compared.add(what);
      return true;
    }

    final doPhys = can(DataField.physical, 'patch / source');
    final doPh = can(DataField.phantom, '+48V');
    final doGrp = can(DataField.grp, 'groups');

    String show(String v) => v.isEmpty ? '(none)' : v;
    final byB = {for (final c in b.channels) c.id: c};
    final idsA = {for (final c in a.channels) c.id};
    final diffs = <DiffItem>[];
    final onlyA = <String>[];
    var unknown = 0;
    for (final ca in a.channels) {
      final cb = byB[ca.id];
      if (cb == null) {
        onlyA.add(ca.id);
        continue;
      }
      if (ca.name.trim() != cb.name.trim()) diffs.add(DiffItem(ca.id, 'name', show(ca.name), show(cb.name)));
      if (doPhys) {
        if (ca.physical == kNotRead || cb.physical == kNotRead) {
          unknown++;
        } else if (ca.physical != cb.physical) {
          diffs.add(DiffItem(ca.id, 'patch', show(ca.physical), show(cb.physical)));
        }
      }
      if (doPh) {
        final la = phantomLabel(ca.phantom, na: ca.phantomNa), lb = phantomLabel(cb.phantom, na: cb.phantomNa);
        if (la == kNotRead || lb == kNotRead) {
          unknown++;
        } else if (la != lb) {
          diffs.add(DiffItem(ca.id, '+48V', la, lb));
        }
      }
      if (doGrp && ca.grp != cb.grp) diffs.add(DiffItem(ca.id, 'groups', show(ca.grp), show(cb.grp)));
    }
    final onlyB = [for (final c in b.channels) if (!idsA.contains(c.id)) c.id];
    return CompareResult(nameOf(a), nameOf(b), compared, excluded, diffs, onlyA, onlyB, unknown);
  }
}

