import 'dart:typed_data';
import '../models/scene_model.dart';
import 'csv_export_service.dart';
import 'share_service.dart';

enum ShareChoice { pdf, pngCurrent, pngAll, csv }

/// The three share primitives; injectable so each choice can be tested without Android.
class ShareActions {
  final Future<void> Function(Uint8List pdf, String base) pdf;
  final Future<void> Function(List<Uint8List> pages, String base, {int? only}) png;
  final Future<void> Function(String csv, String base) csv;
  const ShareActions({required this.pdf, required this.png, required this.csv});
  factory ShareActions.real() =>
      ShareActions(pdf: ShareService.sharePdf, png: ShareService.sharePngs, csv: ShareService.shareCsv);
}

/// Each choice runs exactly one share method and returns (no fall-through).
Future<void> dispatchShare(
  ShareChoice choice, {
  required Scene scene,
  required Uint8List? pdf,
  required List<Uint8List> pages,
  required String base,
  required int currentPage,
  ShareActions? actions,
}) async {
  final a = actions ?? ShareActions.real();
  switch (choice) {
    case ShareChoice.pdf:
      if (pdf == null) throw StateError('No PDF to share.');
      await a.pdf(pdf, base);
      return;
    case ShareChoice.pngCurrent:
      if (pages.isEmpty) throw StateError('No pages to share.');
      await a.png(pages, base, only: pages.length > 1 ? currentPage.clamp(0, pages.length - 1).toInt() : null);
      return;
    case ShareChoice.pngAll:
      if (pages.isEmpty) throw StateError('No pages to share.');
      await a.png(pages, base);
      return;
    case ShareChoice.csv:
      await a.csv(CsvExportService.csv(scene), base);
      return;
  }
}
