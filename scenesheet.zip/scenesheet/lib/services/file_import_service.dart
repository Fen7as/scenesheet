import 'package:file_picker/file_picker.dart';
import '../parsers/mixer_parser.dart';

class FileImportService {
  static Future<MixerFile?> pick() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null) return null;
    final f = r.files.single;
    final b = f.bytes;
    if (b == null) throw SceneException('Could not read this mixer file.');
    return MixerFile(f.name, b);
  }
}
