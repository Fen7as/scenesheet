import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import '../parsers/mixer_parser.dart';

class PickedScene {
  final String name, text;
  PickedScene(this.name, this.text);
}

class FileImportService {
  static Future<PickedScene?> pick() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null) return null;
    final f = r.files.single;
    final b = f.bytes;
    if (b == null) throw SceneException('Could not read the selected file.');
    return PickedScene(f.name, utf8.decode(b, allowMalformed: true));
  }
}
