import '../models/scene_model.dart';

/// Channel list as CSV. Same rows/values as the Scene Sheet channel table; values the
/// format never reads (or that are missing) are written as "–", never as OFF or empty.
class CsvExportService {
  static const headers = ['ch', 'name', 'physical', '+48V', 'low-cut', 'gate', 'dyn', 'insert', 'group', 'link'];

  static String escape(String v) =>
      (v.contains(',') || v.contains('"') || v.contains('\n') || v.contains('\r')) ? '"${v.replaceAll('"', '""')}"' : v;

  static List<List<String>> rows(Scene s) {
    final u = s.unread;
    String f(DataField d, bool? v, {bool na = false}) => stateLabel(v, unread: u.contains(d), na: na);
    return [
      for (final c in s.channels)
        [
          c.id,
          c.name,
          u.contains(DataField.physical) ? kNotRead : c.physical,
          f(DataField.phantom, c.phantom, na: c.phantomNa),
          f(DataField.lowcut, c.lowcut),
          f(DataField.gate, c.gate),
          f(DataField.dyn, c.dyn),
          u.contains(DataField.insert) ? kNotRead : (c.insert == 'OFF' ? '' : c.insert),
          u.contains(DataField.grp) ? kNotRead : c.grp,
          u.contains(DataField.link) ? kNotRead : (c.link == 0 ? 'no' : (c.link == 1 ? 'pair (1st)' : 'pair (2nd)')),
        ],
    ];
  }

  /// UTF-8 text with a leading BOM (so Excel shows Arabic and other non-Latin names correctly).
  static String csv(Scene s) =>
      '\uFEFF${[headers, ...rows(s)].map((r) => r.map(escape).join(',')).join('\r\n')}\r\n';
}
