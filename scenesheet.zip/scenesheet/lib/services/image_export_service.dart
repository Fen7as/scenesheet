import 'dart:typed_data';
import 'package:printing/printing.dart';

class ImageExportService {
  /// Rasterises every PDF page (A4 landscape) to PNG. 200 dpi = 2339x1654 px.
  static Future<List<Uint8List>> render(Uint8List pdf, {double dpi = 200}) async {
    final out = <Uint8List>[];
    await for (final p in Printing.raster(pdf, dpi: dpi)) {
      out.add(await p.toPng());
    }
    return out;
  }
}
