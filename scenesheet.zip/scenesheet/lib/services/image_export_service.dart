import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:printing/printing.dart';

class ImageExportService {
  /// Rasterises every PDF page to opaque white-background PNG (200 dpi).
  static Future<List<Uint8List>> render(Uint8List pdf, {double dpi = 200}) async {
    final out = <Uint8List>[];
    await for (final p in Printing.raster(pdf, dpi: dpi)) {
      out.add(await flattenOnWhite(await p.toPng()));
    }
    return out;
  }

  /// Composites a (possibly transparent) PNG onto solid white.
  static Future<Uint8List> flattenOnWhite(Uint8List png) async {
    final codec = await ui.instantiateImageCodec(png);
    final img = (await codec.getNextFrame()).image;
    final rec = ui.PictureRecorder();
    final c = ui.Canvas(rec);
    c.drawRect(
        ui.Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()), ui.Paint()..color = const ui.Color(0xFFFFFFFF));
    c.drawImage(img, ui.Offset.zero, ui.Paint());
    final flat = await rec.endRecording().toImage(img.width, img.height);
    final data = await flat.toByteData(format: ui.ImageByteFormat.png);
    return data!.buffer.asUint8List();
  }
}
