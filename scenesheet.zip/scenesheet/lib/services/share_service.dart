import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ShareService {
  static String safeName(String s) {
    final r = s.replaceAll(RegExp(r'[^\w\-]+'), '_');
    return r.isEmpty ? 'scene' : r;
  }

  static Future<void> share(Uint8List pdf, List<Uint8List> pages, String base) async {
    final dir = await getTemporaryDirectory();
    final files = <XFile>[];
    final pf = File('${dir.path}/$base.pdf');
    await pf.writeAsBytes(pdf);
    files.add(XFile(pf.path, mimeType: 'application/pdf'));
    for (var i = 0; i < pages.length; i++) {
      final f = File('${dir.path}/${base}_p${i + 1}.png');
      await f.writeAsBytes(pages[i]);
      files.add(XFile(f.path, mimeType: 'image/png'));
    }
    await Share.shareXFiles(files, subject: base);
  }
}
