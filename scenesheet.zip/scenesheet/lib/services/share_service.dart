import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class ShareService {
  static String safeName(String s) {
    final r = s.replaceAll(RegExp(r'[^\w\-]+'), '_');
    return r.isEmpty ? 'scene' : r;
  }

  /// Shares the actual stored scene file (not the generated sheet), via a cache copy.
  static Future<void> shareFile(File stored) async {
    final dir = await getTemporaryDirectory();
    final copy = await stored.copy('${dir.path}/${stored.uri.pathSegments.last}');
    await Share.shareXFiles([XFile(copy.path)], subject: stored.uri.pathSegments.last);
  }

  static Future<File> _tmp(String name, Uint8List b) async {
    final f = File('${(await getTemporaryDirectory()).path}/$name');
    await f.writeAsBytes(b);
    return f;
  }

  /// Share the generated Scene Sheet as PDF (all pages).
  static Future<void> sharePdf(Uint8List pdf, String base) async {
    final f = await _tmp('$base.pdf', pdf);
    await Share.shareXFiles([XFile(f.path, mimeType: 'application/pdf')], subject: base);
  }

  /// Share the channel list as UTF-8 CSV (with BOM so spreadsheets read non-English names).
  static Future<void> shareCsv(String csv, String base) async {
    final f = await _tmp('${base}_channels.csv', Uint8List.fromList(utf8.encode(csv)));
    await Share.shareXFiles([XFile(f.path, mimeType: 'text/csv')], subject: base);
  }

  /// Share PNG page(s): [only] = zero-based single page, otherwise every page.
  static Future<void> sharePngs(List<Uint8List> pages, String base, {int? only}) async {
    final files = <XFile>[];
    for (var i = 0; i < pages.length; i++) {
      if (only != null && i != only) continue;
      files.add(XFile((await _tmp('${base}_p${i + 1}.png', pages[i])).path, mimeType: 'image/png'));
    }
    await Share.shareXFiles(files, subject: base);
  }

  static Future<void> share(Uint8List pdf, List<Uint8List> pages, String base) async {
    final dir = await getTemporaryDirectory();
    final files = <XFile>[];
    final pf = File('${dir.path}/$base.pdf');
    await pf.writeAsBytes(pdf);
    files.add(XFile(pf.path, mimeType: 'application/pdf'));
    for (var i = 0; i < pages.length; i++) {
      final f = File('${dir.path}/${base}_p${i + 1}.png');
      await f.writeAsBytes(pages[i]);
      files.add(XFile(f.path, mimeType: 'image/png'));
    }
    await Share.shareXFiles(files, subject: base);
  }
}
