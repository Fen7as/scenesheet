import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/scene_model.dart';

class SheetLayoutException implements Exception {
  final String message;
  SheetLayoutException(this.message);
  @override
  String toString() => message;
}

const _hdr = PdfColor.fromInt(0xff6b6f9c);
const _idBg = PdfColor.fromInt(0xffe3e5f2);
const _grey = PdfColor.fromInt(0xff9a9a9a);
const _sig = PdfColor.fromInt(0xffa6a6a6);
const signatureText = 'By R. Fenhas';

PdfColor _col(String c) {
  final b = c.endsWith('i') ? c.substring(0, c.length - 1) : c;
  switch (b) {
    case 'RD': return const PdfColor.fromInt(0xffe53935);
    case 'GN': return const PdfColor.fromInt(0xff2e7d32);
    case 'YE': return const PdfColor.fromInt(0xffffeb3b);
    case 'BL': return const PdfColor.fromInt(0xff1a35d6);
    case 'MG': return const PdfColor.fromInt(0xffe91ee3);
    case 'CY': return const PdfColor.fromInt(0xff00bcd4);
    case 'WH': return const PdfColor.fromInt(0xffc8c8c8);
    default: return PdfColors.black;
  }
}

// ---------- table description ----------
enum _K { id, link, name, chk, insert, txt }

class _C {
  final String h;
  final _K k;
  final String Function(Strip) t;
  _C(this.h, this.k, this.t);
}

_C _id(String h) => _C(h, _K.id, (s) => s.id);
_C _link() => _C('link', _K.link, (s) => s.link == 1 ? '┐' : s.link == 2 ? '┘' : '');
_C _name() => _C('name', _K.name, (s) => s.name);
_C _chk(String h, bool? Function(Strip) f) => _C(h, _K.chk, (s) => f(s) == true ? '✓' : '');
_C _insert() => _C('insert', _K.insert, (s) => s.insert == 'OFF' ? '' : s.insert);
_C _txt(String h, String Function(Strip) f) => _C(h, _K.txt, f);

class _T {
  final String title;
  final List<_C> cols;
  final List<Strip> rows;
  final bool full; // spans the whole page width in the normal (non-compact) layout
  _T(this.title, this.cols, this.rows, {this.full = false});
}

/// Exact size of one table at a given font size (all rows have a fixed height, so the
/// height is known BEFORE pagination: a table is never measured by flowing it).
class _M {
  final double fs, rowH, titleH, pad, bar, gap;
  final List<double> w;
  final int n;
  _M(this.fs, this.rowH, this.titleH, this.pad, this.bar, this.gap, this.w, this.n);
  double get width => w.fold(0.0, (a, b) => a + b);
  double get height => titleH + rowH * (n + 1) + 1;
}

_M _measure(_T t, double fs, bool tight) {
  final cw = 0.602 * fs; // DejaVu Sans Mono advance
  final pad = fs * (tight ? 0.22 : 0.32), bar = fs * 0.4, gap = fs * 0.3;
  final w = <double>[];
  for (final c in t.cols) {
    var n = c.h.length;
    for (final r in t.rows) {
      final l = c.t(r).runes.length;
      if (l > n) n = l;
    }
    w.add(n * cw + 2 * pad + (c.k == _K.name ? bar + gap : 0));
  }
  return _M(fs, fs * (tight ? 1.3 : 1.6), fs * (tight ? 1.9 : 2.1), pad, bar, gap, w, t.rows.length);
}

/// Largest font <= fs0 (down to the minimum readable size) where the COMPLETE table fits.
/// Tries normal rows first, then tight rows. Never splits: throws if it cannot fit.
_M _fit(_T t, double fs0, bool tight, double? maxW, double? maxH, double minFs) {
  for (final tt in tight ? [true] : [false, true]) {
    for (var f = fs0; f >= minFs - 1e-6; f -= 0.25) {
      final m = _measure(t, f, tt);
      if ((maxH == null || m.height <= maxH) && (maxW == null || m.width <= maxW)) return m;
    }
  }
  throw SheetLayoutException(
      'The "${t.title}" table cannot fit on one page at the minimum readable text size. Try A3 or fewer sections.');
}

class PlacedTable {
  final String title;
  final int rows;
  final double x, y, w, h, fs;
  final _T _t;
  final _M _m;
  final double _k;
  PlacedTable._(this._t, this._m, this._k, this.x, this.y)
      : title = _t.title,
        rows = _t.rows.length,
        w = _m.width * _k,
        h = _m.height,
        fs = _m.fs;
}

class SheetPlan {
  final List<List<PlacedTable>> pages;
  final double pageW, pageH, margin, contentW, contentH, hdrH, footH, hdrFs, sigFs;
  SheetPlan(this.pages, this.pageW, this.pageH, this.margin, this.contentW, this.contentH, this.hdrH, this.footH,
      this.hdrFs, this.sigFs);
}

class _Col {
  final double x, w;
  double used = 0;
  _Col(this.x, this.w);
}

class PdfExportService {
  static List<_T> _tables(Scene s, SheetOptions o) {
    bool on(Section x) => o.sections.contains(x);
    final all = <_T>[
      if (on(Section.channel))
        _T('Channel', [
          _id('ch'), _link(), _name(),
          _chk('lowcut', (x) => x.lowcut), _chk('gate', (x) => x.gate), _chk('dyn', (x) => x.dyn),
          _insert(), _chk('48V', (x) => x.phantom),
          _txt('grp', (x) => x.grp), _txt('physical', (x) => x.physical),
        ], s.channels, full: true),
      if (on(Section.bus))
        _T('Bus', [_id('ch'), _link(), _name(), _chk('dyn', (x) => x.dyn), _insert()], s.buses),
      if (on(Section.matrix))
        _T('Matrix', [_id('ch'), _link(), _name(), _chk('dyn', (x) => x.dyn), _insert()], s.matrices),
      if (on(Section.aux))
        _T('Aux', [_id('ch'), _link(), _name(), _txt('physical', (x) => x.physical)], s.auxes),
      if (on(Section.main))
        _T('Main', [_C('name', _K.id, (x) => x.id), _chk('dyn', (x) => x.dyn), _insert()], s.main),
      if (on(Section.fx))
        _T('FX-1', [_id('ch'), _link(), _name(), _txt('device', (x) => x.device), _txt('src', (x) => x.src)],
            s.fxReturns),
      if (on(Section.fx))
        _T('FX-2', [_id('ch'), _txt('device', (x) => x.device), _txt('src', (x) => x.src)], s.fxSlots),
    ];
    return all.where((t) => t.rows.isNotEmpty).toList();
  }

  /// Pure layout step (no drawing): decides which complete table goes on which page.
  static SheetPlan plan(Scene s, SheetOptions o) {
    final tables = _tables(s, o);
    if (tables.isEmpty) throw StateError('nothing to render');
    final fmt = o.format;
    final base = fmt == OutputFormat.a3 ? 7.5 : fmt == OutputFormat.a4 ? 6.5 : 9.0;
    final minFs = fmt == OutputFormat.screen ? 7.0 : 5.5;
    final margin = fmt == OutputFormat.a3 ? 28.0 : fmt == OutputFormat.a4 ? 20.0 : 16.0;
    final hdrFs = fmt == OutputFormat.a4 ? 12.0 : 14.0;
    final sigFs = fmt == OutputFormat.a4 ? 5.5 : 6.5;
    final hdrH = hdrFs * 1.3 + 6, footH = sigFs * 1.3 + 6;
    final pf = fmt == OutputFormat.a3 ? PdfPageFormat.a3.landscape : PdfPageFormat.a4.landscape;
    final pageW = fmt == OutputFormat.screen ? 600.0 : pf.width;
    final W = pageW - 2 * margin;
    final tightPref = o.compact;
    final fsUser = math.max(minFs, base * o.textScale.clamp(0.5, 2.5));
    const gx = 12.0;

    SheetPlan make(List<List<PlacedTable>> pages, double pageH, double H) =>
        SheetPlan(pages, pageW, pageH, margin, W, H, hdrH, footH, hdrFs, sigFs);

    if (fmt == OutputFormat.screen) {
      final page = <PlacedTable>[];
      var y = 0.0;
      for (final t in tables) {
        final m = _fit(t, fsUser, tightPref, W, null, minFs);
        final k = math.max(1.0, W / m.width);
        page.add(PlacedTable._(t, m, k, 0, y));
        y += m.height + 10;
      }
      final H = y - 10;
      return make([page], 2 * margin + hdrH + footH + H, H);
    }

    final pageH = pf.height;
    final H = pageH - 2 * margin - hdrH - footH;

    if (!o.compact) {
      // Normal: Channel full width; other tables two per row. Each block (header + table[s])
      // is placed whole on the current page or moved whole to the next one.
      final blocks = <List<_T>>[];
      var pend = <_T>[];
      for (final t in tables) {
        if (t.full) {
          if (pend.isNotEmpty) {
            blocks.add(pend);
            pend = [];
          }
          blocks.add([t]);
        } else {
          pend.add(t);
          if (pend.length == 2) {
            blocks.add(pend);
            pend = [];
          }
        }
      }
      if (pend.isNotEmpty) blocks.add(pend);

      final pages = <List<PlacedTable>>[[]];
      var y = 0.0;
      const gy = 8.0;
      for (final b in blocks) {
        final single = b.length == 1 && b[0].full;
        final tw = single ? W : (W - gx) / 2;
        final ms = [for (final t in b) _fit(t, fsUser, false, tw, H, minFs)];
        final rh = ms.map((m) => m.height).reduce(math.max);
        if (pages.last.isNotEmpty && y + gy + rh > H) {
          pages.add([]);
          y = 0;
        } else if (pages.last.isNotEmpty) {
          y += gy;
        }
        var x = 0.0;
        for (var i = 0; i < b.length; i++) {
          pages.last.add(PlacedTable._(b[i], ms[i], math.max(1.0, tw / ms[i].width), x, y));
          x += tw + gx;
        }
        y += rh;
      }
      return make(pages, pageH, H);
    }

    // Compact: content-sized tables packed into columns; largest uniform font that
    // gives the fewest pages (never below the minimum readable size).
    List<List<PlacedTable>>? best;
    for (var f = base * 1.3; f >= minFs - 1e-6; f -= 0.25) {
      final p = _pack(tables, f, W, H);
      if (p == null) continue;
      if (best == null || p.length < best.length) best = p;
    }
    if (best == null) {
      throw SheetLayoutException(
          'These tables cannot fit on one page at the minimum readable text size. Try A3 or fewer sections.');
    }
    return make(best, pageH, H);
  }

  static List<List<PlacedTable>>? _pack(List<_T> ts, double fs, double W, double H) {
    const gx = 12.0, gy = 6.0;
    final pages = <List<PlacedTable>>[];
    var cols = <_Col>[];
    var cur = <PlacedTable>[];
    void newPage() {
      cur = [];
      pages.add(cur);
      cols = [];
    }

    newPage();
    for (final t in ts) {
      final m = _measure(t, fs, true);
      if (m.height > H || m.width > W) return null;
      _Col? best;
      var bestLeft = double.infinity;
      for (final c in cols) {
        if (m.width <= c.w + 0.01) {
          final need = c.used == 0 ? m.height : c.used + gy + m.height;
          if (need <= H && H - need < bestLeft) {
            bestLeft = H - need;
            best = c;
          }
        }
      }
      if (best == null) {
        final x = cols.isEmpty ? 0.0 : cols.last.x + cols.last.w + gx;
        if (x + m.width <= W + 0.01) {
          best = _Col(x, m.width);
        } else {
          newPage();
          best = _Col(0, m.width);
        }
        cols.add(best);
      }
      final y = best.used == 0 ? 0.0 : best.used + gy;
      cur.add(PlacedTable._(t, m, 1.0, best.x, y));
      best.used = y + m.height;
    }
    return pages;
  }

  // ---------- drawing ----------
  static pw.Widget _cell(_C c, Strip? s, _M m) {
    final head = s == null;
    final txt = head ? c.h : c.t(s);
    final center = c.k == _K.link || c.k == _K.chk;
    final grey = !head && c.k == _K.insert && !s.insertOn;
    final text = pw.Text(txt,
        maxLines: 1,
        softWrap: false,
        overflow: pw.TextOverflow.clip,
        style: pw.TextStyle(
            fontSize: m.fs,
            color: head ? PdfColors.white : (grey ? _grey : PdfColors.black),
            fontWeight: head || c.k == _K.chk ? pw.FontWeight.bold : pw.FontWeight.normal));
    return pw.Container(
      height: m.rowH,
      color: !head && c.k == _K.id ? _idBg : null,
      alignment: center ? pw.Alignment.center : pw.Alignment.centerLeft,
      padding: pw.EdgeInsets.symmetric(horizontal: m.pad),
      child: !head && c.k == _K.name
          ? pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
              pw.Container(width: m.bar, height: m.rowH * 0.7, color: _col(s.color)),
              pw.SizedBox(width: m.gap),
              pw.Expanded(child: text),
            ])
          : text,
    );
  }

  static pw.Widget _widget(PlacedTable p) {
    final t = p._t, m = p._m, k = p._k;
    return pw.SizedBox(
      width: p.w,
      height: p.h,
      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.SizedBox(
            height: m.titleH,
            child: pw.Align(
                alignment: pw.Alignment.centerLeft,
                child: pw.Text(t.title, style: pw.TextStyle(fontSize: m.fs * 1.4, fontWeight: pw.FontWeight.bold)))),
        pw.Table(
          border: pw.TableBorder.all(width: 0.4, color: PdfColors.grey700),
          defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
          columnWidths: {for (var i = 0; i < t.cols.length; i++) i: pw.FixedColumnWidth(m.w[i] * k)},
          children: [
            pw.TableRow(
                decoration: const pw.BoxDecoration(color: _hdr),
                children: [for (final c in t.cols) _cell(c, null, m)]),
            for (final r in t.rows) pw.TableRow(children: [for (final c in t.cols) _cell(c, r, m)]),
          ],
        ),
      ]),
    );
  }

  static Future<Uint8List> build(Scene s, SheetOptions o) async {
    final reg = pw.Font.ttf(await rootBundle.load('assets/mono.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/mono-bold.ttf'));
    final p = plan(s, o);
    final doc = pw.Document(title: s.name, creator: 'SceneSheet');
    final theme = pw.ThemeData.withFont(base: reg, bold: bold);
    final title = '${s.name.isEmpty ? s.fileName : s.name}   -   ${s.mixer}';
    // Always-white page, independent of any system/app theme.
    pw.Widget white(pw.Context c) =>
        pw.FullPage(ignoreMargins: true, child: pw.Container(color: PdfColors.white));

    for (final page in p.pages) {
      doc.addPage(pw.Page(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat(p.pageW, p.pageH),
          margin: pw.EdgeInsets.all(p.margin),
          theme: theme,
          buildBackground: white,
        ),
        build: (c) => pw.Stack(fit: pw.StackFit.expand, children: [
          pw.Positioned(
              left: 0,
              top: 0,
              child: pw.Text(title, style: pw.TextStyle(fontSize: p.hdrFs, fontWeight: pw.FontWeight.bold))),
          for (final t in page) pw.Positioned(left: t.x, top: p.hdrH + t.y, child: _widget(t)),
          pw.Positioned(
              right: 0, bottom: 0, child: pw.Text(signatureText, style: pw.TextStyle(fontSize: p.sigFs, color: _sig))),
        ]),
      ));
    }
    return doc.save();
  }
}
