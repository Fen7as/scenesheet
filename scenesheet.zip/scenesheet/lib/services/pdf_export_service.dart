import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/scene_model.dart';

const _hdr = PdfColor.fromInt(0xff6b6f9c);
const _idBg = PdfColor.fromInt(0xffe3e5f2);
const _grey = PdfColor.fromInt(0xff9a9a9a);
double _fs = 6.5;

PdfColor _col(String c) {
  final b = c.endsWith('i') ? c.substring(0, c.length - 1) : c;
  switch (b) {
    case 'RD': return const PdfColor.fromInt(0xffe53935);
    case 'GN': return const PdfColor.fromInt(0xff2e7d32);
    case 'YE': return const PdfColor.fromInt(0xffffeb3b);
    case 'BL': return const PdfColor.fromInt(0xff1a35d6);
    case 'MG': return const PdfColor.fromInt(0xffe91ee3);
    case 'CY': return const PdfColor.fromInt(0xff00bcd4);
    case 'WH': return const PdfColor.fromInt(0xffc8c8c8);
    default: return PdfColors.black;
  }
}

class _C {
  final String h;
  final double w;
  final pw.Widget Function(Strip) b;
  _C(this.h, this.w, this.b);
}

pw.Widget _t(String s, {bool bold = false, PdfColor? color, PdfColor? bg, bool center = false}) =>
    pw.Container(
      color: bg,
      alignment: center ? pw.Alignment.center : pw.Alignment.centerLeft,
      padding: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 1.3),
      child: pw.Text(s,
          maxLines: 1,
          softWrap: false,
          overflow: pw.TextOverflow.clip,
          style: pw.TextStyle(
              fontSize: _fs, color: color, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
    );

_C _id(String h, [double w = 1.2]) => _C(h, w, (s) => _t(s.id, bg: _idBg));
_C _link() => _C('link', 0.8, (s) => _t(s.link == 1 ? '┐' : s.link == 2 ? '┘' : '', center: true));
_C _name() => _C('name', 4.5, (s) {
      final c = s.color == 'OFF' && s.name.isEmpty ? PdfColors.black : _col(s.color);
      return pw.Row(children: [
        pw.Container(width: 2.5, height: _fs * 1.46, color: c),
        pw.SizedBox(width: 2),
        pw.Expanded(child: _t(s.name)),
      ]);
    });
_C _chk(String h, bool? Function(Strip) f, [double w = 1.1]) =>
    _C(h, w, (s) => _t(f(s) == true ? '✓' : '', center: true, bold: true));
_C _insert() => _C('insert', 1.8, (s) {
      final v = s.insert;
      if (v.isEmpty || v == 'OFF') return _t('');
      return _t(v, color: s.insertOn ? PdfColors.black : _grey);
    });
_C _txt(String h, double w, String Function(Strip) f) => _C(h, w, (s) => _t(f(s)));

pw.Widget? _section(String title, List<Strip> rows, List<_C> cols) {
  if (rows.isEmpty) return null;
  return pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
    pw.Text(title, style: pw.TextStyle(fontSize: _fs * 1.4, fontWeight: pw.FontWeight.bold)),
    pw.SizedBox(height: 2),
    pw.Table(
      border: pw.TableBorder.all(width: 0.4, color: PdfColors.grey700),
      defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
      columnWidths: {for (var i = 0; i < cols.length; i++) i: pw.FlexColumnWidth(cols[i].w)},
      children: [
        pw.TableRow(
            decoration: const pw.BoxDecoration(color: _hdr),
            repeat: true,
            children: [for (final c in cols) _t(c.h, bold: true, color: PdfColors.white)]),
        for (final r in rows) pw.TableRow(children: [for (final c in cols) c.b(r)]),
      ],
    ),
  ]);
}

pw.Widget _row(pw.Widget a, pw.Widget? b) => pw.Row(
    crossAxisAlignment: pw.CrossAxisAlignment.start,
    children: [pw.Expanded(child: a), pw.SizedBox(width: 14), pw.Expanded(child: b ?? pw.SizedBox())]);

class PdfExportService {
  static Future<Uint8List> build(Scene s, SheetOptions o) async {
    final reg = pw.Font.ttf(await rootBundle.load('assets/mono.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/mono-bold.ttf'));
    final doc = pw.Document(title: s.name, creator: 'SceneSheet');
    final a4 = o.format == OutputFormat.a4;
    _fs = a4 ? 6.5 : 9;
    bool on(Section x) => o.sections.contains(x);

    final chan = !on(Section.channel) ? null : _section('Channel', s.channels, [
      _id('ch'), _link(), _name(),
      _chk('lowcut', (x) => x.lowcut), _chk('gate', (x) => x.gate), _chk('dyn', (x) => x.dyn),
      _insert(), _chk('48V', (x) => x.phantom),
      _txt('grp', 1.4, (x) => x.grp), _txt('physical', 4, (x) => x.physical),
    ]);
    final bus = !on(Section.bus) ? null
        : _section('Bus', s.buses, [_id('ch'), _link(), _name(), _chk('dyn', (x) => x.dyn), _insert()]);
    final mtx = !on(Section.matrix) ? null
        : _section('Matrix', s.matrices, [_id('ch'), _link(), _name(), _chk('dyn', (x) => x.dyn), _insert()]);
    final aux = !on(Section.aux) ? null
        : _section('Aux', s.auxes, [_id('ch'), _link(), _name(), _txt('physical', 3.5, (x) => x.physical)]);
    final main = !on(Section.main) ? null : _section('Main', s.main, [
      _C('name', 1.2, (x) => _t(x.id, bg: _idBg)), _chk('dyn', (x) => x.dyn), _insert(),
    ]);
    final fx1 = !on(Section.fx) ? null : _section('FX-1', s.fxReturns, [
      _id('ch', 1.2), _link(), _name(), _txt('device', 1.6, (x) => x.device), _txt('src', 1.4, (x) => x.src),
    ]);
    final fx2 = !on(Section.fx) ? null : _section('FX-2', s.fxSlots, [
      _id('ch', 1.2), _txt('device', 2.2, (x) => x.device), _txt('src', 1.6, (x) => x.src),
    ]);

    final theme = pw.ThemeData.withFont(base: reg, bold: bold);
    final title = '${s.name.isEmpty ? s.fileName : s.name}   -   ${s.mixer}';
    pw.Widget head() => pw.Padding(
        padding: const pw.EdgeInsets.only(bottom: 4),
        child: pw.Text(title, style: pw.TextStyle(fontSize: a4 ? 12 : 14, fontWeight: pw.FontWeight.bold)));

    if (a4) {
      final small = [bus, mtx, aux, main, fx1, fx2].whereType<pw.Widget>().toList();
      if (chan == null && small.isEmpty) throw StateError('nothing to render');
      doc.addPage(pw.MultiPage(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat.a4.landscape,
          margin: const pw.EdgeInsets.all(20),
          theme: theme,
        ),
        header: (c) => head(),
        build: (c) => [
          if (chan != null) chan,
          for (var i = 0; i < small.length; i += 2) ...[
            pw.SizedBox(height: 10),
            _row(small[i], i + 1 < small.length ? small[i + 1] : null),
          ],
        ],
      ));
    } else {
      // Screen: one continuous single-column page, larger text.
      final items = <MapEntry<pw.Widget?, int>>[
        MapEntry(chan, s.channels.length), MapEntry(bus, s.buses.length),
        MapEntry(mtx, s.matrices.length), MapEntry(aux, s.auxes.length),
        MapEntry(main, s.main.length), MapEntry(fx1, s.fxReturns.length),
        MapEntry(fx2, s.fxSlots.length),
      ].where((e) => e.key != null).toList();
      if (items.isEmpty) throw StateError('nothing to render');
      var h = 32.0 + 30;
      for (final e in items) {
        h += (e.value + 1) * 15 + 30;
      }
      doc.addPage(pw.Page(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat(600, h),
          margin: const pw.EdgeInsets.all(16),
          theme: theme,
        ),
        build: (c) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          head(),
          for (final e in items) ...[pw.SizedBox(height: 12), e.key!],
        ]),
      ));
    }
    return doc.save();
  }
}
