import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/scene_model.dart';

class SheetLayoutException implements Exception {
  final String message;
  SheetLayoutException(this.message);
  @override
  String toString() => message;
}

const _hdr = PdfColor.fromInt(0xff6b6f9c);
const _idBg = PdfColor.fromInt(0xffe3e5f2);
const _grey = PdfColor.fromInt(0xff9a9a9a);
const _sig = PdfColor.fromInt(0xffa6a6a6);
const signatureText = 'By R. Fenhas';

PdfColor _col(String c) {
  final b = c.endsWith('i') ? c.substring(0, c.length - 1) : c;
  switch (b) {
    case 'RD': return const PdfColor.fromInt(0xffe53935);
    case 'GN': return const PdfColor.fromInt(0xff2e7d32);
    case 'YE': return const PdfColor.fromInt(0xffffeb3b);
    case 'BL': return const PdfColor.fromInt(0xff1a35d6);
    case 'MG': return const PdfColor.fromInt(0xffe91ee3);
    case 'CY': return const PdfColor.fromInt(0xff00bcd4);
    case 'WH': return const PdfColor.fromInt(0xffc8c8c8);
    default: return PdfColors.black;
  }
}

/// Phantom label: not read -> "–", not applicable -> "N/A", never OFF unless confirmed.
String phantomLabel(bool? v, {bool na = false, bool unread = false}) => stateLabel(v, na: na, unread: unread);

// ---------- table description ----------
enum _K { id, link, name, state, insert, txt, blank }

class _C {
  final String h;
  final _K k;
  final String Function(Strip) t;
  final int minChars;
  _C(this.h, this.k, this.t, {this.minChars = 0});
}

class _T {
  final String title;
  final List<_C> cols;
  final List<Strip> rows;
  final bool full; // spans the whole page width in the normal (non-compact) layout
  final double? rowK; // row height factor override (hand-writing rows)
  _T(this.title, this.cols, this.rows, {this.full = false, this.rowK});
  _T withRows(String newTitle, List<Strip> r) => _T(newTitle, cols, r, full: full, rowK: rowK);
}

/// Exact size of one table at a given font size (all rows have a fixed height, so the
/// height is known BEFORE pagination: a table is never measured by flowing it).
class _M {
  final double fs, rowH, titleH, pad, bar, gap;
  final List<double> w;
  final int n;
  _M(this.fs, this.rowH, this.titleH, this.pad, this.bar, this.gap, this.w, this.n);
  double get width => w.fold(0.0, (a, b) => a + b);
  double get height => titleH + rowH * (n + 1) + 1;
}

_M _measure(_T t, double fs, bool tight) {
  final cw = 0.602 * fs; // DejaVu Sans Mono advance
  final pad = fs * (tight ? 0.22 : 0.32), bar = fs * 0.4, gap = fs * 0.3;
  final w = <double>[];
  for (final c in t.cols) {
    var n = math.max(c.h.length, c.minChars);
    for (final r in t.rows) {
      final l = c.t(r).runes.length;
      if (l > n) n = l;
    }
    w.add(n * cw + 2 * pad + (c.k == _K.name ? bar + gap : 0));
  }
  return _M(fs, fs * (t.rowK ?? (tight ? 1.3 : 1.6)), fs * (tight ? 1.9 : 2.1), pad, bar, gap, w, t.rows.length);
}

/// Largest font <= fs0 (down to the minimum readable size) where the COMPLETE table fits.
/// Tries normal rows first, then tight rows. Never splits: throws if it cannot fit.
_M _fit(_T t, double fs0, bool tight, double? maxW, double? maxH, double minFs) {
  for (final tt in tight ? [true] : [false, true]) {
    for (var f = fs0; f >= minFs - 1e-6; f -= 0.25) {
      final m = _measure(t, f, tt);
      if ((maxH == null || m.height <= maxH) && (maxW == null || m.width <= maxW)) return m;
    }
  }
  throw SheetLayoutException(
      'The "${t.title}" table cannot fit on one page at the minimum readable text size. Try A3 or fewer sections.');
}

class PlacedTable {
  final String title;
  final int rows;
  final double x, y, w, h, fs;
  final _T _t;
  final _M _m;
  final double _k;
  PlacedTable._(this._t, this._m, this._k, this.x, this.y)
      : title = _t.title,
        rows = _t.rows.length,
        w = _m.width * _k,
        h = _m.height,
        fs = _m.fs;
}

class SheetPlan {
  final List<List<PlacedTable>> pages;
  final double pageW, pageH, margin, contentW, contentH, hdrH, footH, hdrFs, sumFs, sigFs;
  final String summary, footnote;
  SheetPlan(this.pages, this.pageW, this.pageH, this.margin, this.contentW, this.contentH, this.hdrH, this.footH,
      this.hdrFs, this.sumFs, this.sigFs, this.summary, this.footnote);
}

class _Col {
  final double x, w;
  double used = 0;
  _Col(this.x, this.w);
}

class PdfExportService {
  /// Legend printed on every page; names the fields this format never reads.
  static String footnote(Scene s) {
    const base = '✓ on · OFF = confirmed off · – = not read from this file · N/A = not applicable';
    if (s.unread.isEmpty) return base;
    final names = [for (final f in DataField.values) if (s.unread.contains(f)) fieldLabel(f)];
    return '$base. Not read for this format: ${names.join(', ')}.';
  }

  static List<_T> _tables(Scene s, SheetOptions o) {
    if (o.inputList) return _inputListTables(s);
    final u = s.unread;
    String flag(DataField f, bool? v, {bool na = false, String on = '✓'}) =>
        stateLabel(v, unread: u.contains(f), na: na, on: on);
    _C id(String h) => _C(h, _K.id, (x) => x.id);
    final link = _C('link', _K.link,
        (x) => u.contains(DataField.link) ? kNotRead : (x.link == 1 ? '┐' : x.link == 2 ? '┘' : ''));
    final name = _C('name', _K.name, (x) => x.name);
    _C chk(String h, DataField f, bool? Function(Strip) g) => _C(h, _K.state, (x) => flag(f, g(x)));
    final dyn = chk('dyn', DataField.dyn, (x) => x.dyn);
    final insert = _C('insert', _K.insert,
        (x) => u.contains(DataField.insert) ? kNotRead : (x.insert == 'OFF' ? '' : x.insert));
    final phys = _C('physical', _K.txt, (x) => u.contains(DataField.physical) ? kNotRead : x.physical);
    bool on(Section x) => o.sections.contains(x);
    final all = <_T>[
      if (on(Section.channel))
        _T('Channel', [
          id('ch'), link, name,
          chk('lowcut', DataField.lowcut, (x) => x.lowcut), chk('gate', DataField.gate, (x) => x.gate), dyn,
          insert,
          _C('+48V', _K.state, (x) => flag(DataField.phantom, x.phantom, na: x.phantomNa, on: 'ON')),
          _C('grp', _K.txt, (x) => u.contains(DataField.grp) ? kNotRead : x.grp), phys,
        ], s.channels, full: true),
      if (on(Section.bus)) _T('Bus', [id('ch'), link, name, dyn, insert], s.buses),
      if (on(Section.matrix)) _T('Matrix', [id('ch'), link, name, dyn, insert], s.matrices),
      if (on(Section.aux)) _T('Aux', [id('ch'), link, name, phys], s.auxes),
      if (on(Section.main)) _T('Main', [_C('name', _K.id, (x) => x.id), dyn, insert], s.main),
      if (on(Section.fx))
        _T('FX-1', [id('ch'), link, name, _C('device', _K.txt, (x) => x.device), _C('src', _K.txt, (x) => x.src)],
            s.fxReturns),
      if (on(Section.fx))
        _T('FX-2', [id('ch'), _C('device', _K.txt, (x) => x.device), _C('src', _K.txt, (x) => x.src)], s.fxSlots),
    ];
    return all.where((t) => t.rows.isNotEmpty).toList();
  }

  /// Stage hand-off list: channels sorted by physical socket where the file reliably gives it,
  /// channels without a known socket listed separately in channel order. Blank columns for hand-writing.
  static List<_T> _inputListTables(Scene s) {
    final u = s.unread;
    final cols = [
      _C('socket', _K.txt, (x) => u.contains(DataField.physical) ? kNotRead : (x.physical.isEmpty ? '(none)' : x.physical)),
      _C('ch', _K.id, (x) => x.id),
      _C('name', _K.name, (x) => x.name),
      _C('+48V', _K.state, (x) => stateLabel(x.phantom, unread: u.contains(DataField.phantom), na: x.phantomNa)),
      _C('mic / source', _K.blank, (x) => '', minChars: 16),
      _C('stand', _K.blank, (x) => '', minChars: 8),
      _C('cable', _K.blank, (x) => '', minChars: 8),
      _C('notes', _K.blank, (x) => '', minChars: 22),
    ];
    final onBox = inputListOrder(s);
    final other = s.channels.where((c) => c.portRank == null).toList();
    return [
      if (onBox.isNotEmpty) _T('Input List - by input socket', cols, onBox, full: true, rowK: 2.6),
      if (other.isNotEmpty) _T('Input List - socket not reported (channel order)', cols, other, full: true, rowK: 2.6),
    ];
  }

  /// Channels with a reliably known input socket, sorted by socket (then channel id).
  static List<Strip> inputListOrder(Scene s) => s.channels.where((c) => c.portRank != null).toList()
    ..sort((a, b) {
      final r = a.portRank!.compareTo(b.portRank!);
      return r != 0 ? r : a.id.compareTo(b.id);
    });

  /// Pure layout step (no drawing): decides which complete table goes on which page.
  static SheetPlan plan(Scene s, SheetOptions o) {
    final tables = _tables(s, o);
    if (tables.isEmpty) throw StateError('nothing to render');
    final fmt = o.format;
    final base = fmt == OutputFormat.a3 ? 7.5 : fmt == OutputFormat.a4 ? 6.5 : 9.0;
    final minFs = fmt == OutputFormat.screen ? 7.0 : 5.5;
    final margin = fmt == OutputFormat.a3 ? 28.0 : fmt == OutputFormat.a4 ? 20.0 : 16.0;
    final hdrFs = fmt == OutputFormat.a4 ? 12.0 : 14.0;
    final sigFs = fmt == OutputFormat.a4 ? 5.5 : 6.5;
    final sumFs = sigFs + 1.5;
    final hdrH = hdrFs * 1.3 + sumFs * 1.3 + 8, footH = sigFs * 1.25 * 2 + 6;
    final pf = fmt == OutputFormat.a3 ? PdfPageFormat.a3.landscape : PdfPageFormat.a4.landscape;
    final pageW = fmt == OutputFormat.screen ? 600.0 : pf.width;
    final W = pageW - 2 * margin;
    final tightPref = o.compact && !o.inputList;
    final fsUser = math.max(minFs, base * o.textScale.clamp(0.5, 2.5));
    final summary = phantomSummary(s), note = footnote(s);
    const gx = 12.0;

    SheetPlan make(List<List<PlacedTable>> pages, double pageH, double H) =>
        SheetPlan(pages, pageW, pageH, margin, W, H, hdrH, footH, hdrFs, sumFs, sigFs, summary, note);

    if (fmt == OutputFormat.screen) {
      final page = <PlacedTable>[];
      var y = 0.0;
      for (final t in tables) {
        final m = _fit(t, fsUser, tightPref, W, null, minFs);
        final k = math.max(1.0, W / m.width);
        page.add(PlacedTable._(t, m, k, 0, y));
        y += m.height + 10;
      }
      final H = y - 10;
      return make([page], 2 * margin + hdrH + footH + H, H);
    }

    final pageH = pf.height;
    final H = pageH - 2 * margin - hdrH - footH;

    if (o.inputList) {
      // Each chunk is a COMPLETE table on its own page (header repeated), never a split table.
      final pages = <List<PlacedTable>>[];
      for (final t in tables) {
        var fs = fsUser;
        int cap(double f) {
          final m = _measure(t, f, false);
          return ((H - m.titleH - 1) / m.rowH).floor() - 1;
        }

        while (cap(fs) < 8 && fs - 0.25 >= minFs - 1e-6) {
          fs -= 0.25;
        }
        final c = cap(fs);
        if (c < 3) {
          throw SheetLayoutException('The Input List cannot fit on one page at the minimum readable text size. Try A3.');
        }
        final n = (t.rows.length / c).ceil();
        for (var i = 0; i < n; i++) {
          final chunk = t.rows.sublist(i * c, math.min(t.rows.length, (i + 1) * c));
          final ct = t.withRows(n > 1 ? '${t.title} (${i + 1}/$n)' : t.title, chunk);
          final m = _fit(ct, fs, false, W, H, minFs);
          pages.add([PlacedTable._(ct, m, math.max(1.0, W / m.width), 0, 0)]);
        }
      }
      return make(pages, pageH, H);
    }

    if (!o.compact) {
      // Normal: Channel full width; other tables two per row. Each block (header + table[s])
      // is placed whole on the current page or moved whole to the next one.
      final blocks = <List<_T>>[];
      var pend = <_T>[];
      for (final t in tables) {
        if (t.full) {
          if (pend.isNotEmpty) {
            blocks.add(pend);
            pend = [];
          }
          blocks.add([t]);
        } else {
          pend.add(t);
          if (pend.length == 2) {
            blocks.add(pend);
            pend = [];
          }
        }
      }
      if (pend.isNotEmpty) blocks.add(pend);

      final pages = <List<PlacedTable>>[[]];
      var y = 0.0;
      const gy = 8.0;
      for (final b in blocks) {
        final single = b.length == 1 && b[0].full;
        final tw = single ? W : (W - gx) / 2;
        final ms = [for (final t in b) _fit(t, fsUser, false, tw, H, minFs)];
        final rh = ms.map((m) => m.height).reduce(math.max);
        if (pages.last.isNotEmpty && y + gy + rh > H) {
          pages.add([]);
          y = 0;
        } else if (pages.last.isNotEmpty) {
          y += gy;
        }
        var x = 0.0;
        for (var i = 0; i < b.length; i++) {
          pages.last.add(PlacedTable._(b[i], ms[i], math.max(1.0, tw / ms[i].width), x, y));
          x += tw + gx;
        }
        y += rh;
      }
      return make(pages, pageH, H);
    }

    // Compact: content-sized tables packed into columns; largest uniform font that
    // gives the fewest pages (never below the minimum readable size).
    List<List<PlacedTable>>? best;
    for (var f = base * 1.3; f >= minFs - 1e-6; f -= 0.25) {
      final p = _pack(tables, f, W, H);
      if (p == null) continue;
      if (best == null || p.length < best.length) best = p;
    }
    if (best == null) {
      throw SheetLayoutException(
          'These tables cannot fit on one page at the minimum readable text size. Try A3 or fewer sections.');
    }
    return make(best, pageH, H);
  }

  static List<List<PlacedTable>>? _pack(List<_T> ts, double fs, double W, double H) {
    const gx = 12.0, gy = 6.0;
    final pages = <List<PlacedTable>>[];
    var cols = <_Col>[];
    var cur = <PlacedTable>[];
    void newPage() {
      cur = [];
      pages.add(cur);
      cols = [];
    }

    newPage();
    for (final t in ts) {
      final m = _measure(t, fs, true);
      if (m.height > H || m.width > W) return null;
      _Col? best;
      var bestLeft = double.infinity;
      for (final c in cols) {
        if (m.width <= c.w + 0.01) {
          final need = c.used == 0 ? m.height : c.used + gy + m.height;
          if (need <= H && H - need < bestLeft) {
            bestLeft = H - need;
            best = c;
          }
        }
      }
      if (best == null) {
        final x = cols.isEmpty ? 0.0 : cols.last.x + cols.last.w + gx;
        if (x + m.width <= W + 0.01) {
          best = _Col(x, m.width);
        } else {
          newPage();
          best = _Col(0, m.width);
        }
        cols.add(best);
      }
      final y = best.used == 0 ? 0.0 : best.used + gy;
      cur.add(PlacedTable._(t, m, 1.0, best.x, y));
      best.used = y + m.height;
    }
    return pages;
  }

  // ---------- drawing ----------
  static pw.Widget _cell(_C c, Strip? st, _M m) {
    final txt = st == null ? c.h : c.t(st);
    final center = c.k == _K.link || c.k == _K.state;
    final strong = st != null && c.k == _K.state && (txt == 'ON' || txt == '✓');
    final grey = st != null &&
        (txt == kNotRead ||
            (c.k == _K.state && (txt == 'OFF' || txt == 'N/A')) ||
            (c.k == _K.insert && !st.insertOn));
    final text = pw.Text(txt,
        maxLines: 1,
        softWrap: false,
        overflow: pw.TextOverflow.clip,
        style: pw.TextStyle(
            fontSize: m.fs,
            color: st == null ? PdfColors.white : (grey ? _grey : PdfColors.black),
            fontWeight: st == null || strong ? pw.FontWeight.bold : pw.FontWeight.normal));
    return pw.Container(
      height: m.rowH,
      color: st != null && c.k == _K.id ? _idBg : null,
      alignment: center ? pw.Alignment.center : pw.Alignment.centerLeft,
      padding: pw.EdgeInsets.symmetric(horizontal: m.pad),
      child: st != null && c.k == _K.name
          ? pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
              pw.Container(width: m.bar, height: m.rowH * 0.7, color: _col(st.color)),
              pw.SizedBox(width: m.gap),
              pw.Expanded(child: text),
            ])
          : text,
    );
  }

  static pw.Widget _widget(PlacedTable p) {
    final t = p._t, m = p._m, k = p._k;
    return pw.SizedBox(
      width: p.w,
      height: p.h,
      child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.SizedBox(
            height: m.titleH,
            child: pw.Align(
                alignment: pw.Alignment.centerLeft,
                child: pw.Text(t.title, style: pw.TextStyle(fontSize: m.fs * 1.4, fontWeight: pw.FontWeight.bold)))),
        pw.Table(
          border: pw.TableBorder.all(width: 0.4, color: PdfColors.grey700),
          defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
          columnWidths: {for (var i = 0; i < t.cols.length; i++) i: pw.FixedColumnWidth(m.w[i] * k)},
          children: [
            pw.TableRow(
                decoration: const pw.BoxDecoration(color: _hdr),
                children: [for (final c in t.cols) _cell(c, null, m)]),
            for (final r in t.rows) pw.TableRow(children: [for (final c in t.cols) _cell(c, r, m)]),
          ],
        ),
      ]),
    );
  }

  static Future<Uint8List> build(Scene s, SheetOptions o) async {
    final reg = pw.Font.ttf(await rootBundle.load('assets/mono.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/mono-bold.ttf'));
    final p = plan(s, o);
    final doc = pw.Document(title: s.name, creator: 'SceneSheet');
    final theme = pw.ThemeData.withFont(base: reg, bold: bold);
    final title = '${s.name.isEmpty ? s.fileName : s.name}   -   ${s.mixer}';
    final sigW = signatureText.length * p.sigFs * 0.62 + 10;
    // Always-white page, independent of any system/app theme.
    pw.Widget white(pw.Context c) =>
        pw.FullPage(ignoreMargins: true, child: pw.Container(color: PdfColors.white));

    for (final page in p.pages) {
      doc.addPage(pw.Page(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat(p.pageW, p.pageH),
          margin: pw.EdgeInsets.all(p.margin),
          theme: theme,
          buildBackground: white,
        ),
        build: (c) => pw.Stack(fit: pw.StackFit.expand, children: [
          pw.Positioned(
              left: 0,
              top: 0,
              child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text(title, style: pw.TextStyle(fontSize: p.hdrFs, fontWeight: pw.FontWeight.bold)),
                if (p.summary.isNotEmpty)
                  pw.Text(p.summary, style: pw.TextStyle(fontSize: p.sumFs, color: PdfColors.grey800)),
              ])),
          for (final t in page) pw.Positioned(left: t.x, top: p.hdrH + t.y, child: _widget(t)),
          pw.Positioned(
              left: 0,
              bottom: 0,
              right: sigW,
              child: pw.Text(p.footnote, style: pw.TextStyle(fontSize: p.sigFs, color: _sig))),
          pw.Positioned(
              right: 0, bottom: 0, child: pw.Text(signatureText, style: pw.TextStyle(fontSize: p.sigFs, color: _sig))),
        ]),
      ));
    }
    return doc.save();
  }
}
