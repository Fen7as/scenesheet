import '../models/scene_model.dart';

enum CheckLevel { warning, info }

class CheckItem {
  final CheckLevel level;
  final String title, detail;
  final List<String> channels;
  const CheckItem(this.level, this.title, this.detail, [this.channels = const []]);
}

/// Read-only, explainable checks on parsed data. Not a complete validation.
class ChecksService {
  static const scope = 'These checks only cover: shared input sockets, unnamed channels with +48V ON, '
      'named channels without an input, and fields that could not be read. They are not a full validation of the scene.';

  static List<CheckItem> run(Scene s) {
    final out = <CheckItem>[];
    final u = s.unread;

    // 1. Unnamed channels with +48V positively known ON (warning).
    if (!u.contains(DataField.phantom)) {
      final ids = [for (final c in s.channels) if (c.phantom == true && c.name.trim().isEmpty) c.id];
      if (ids.isNotEmpty) {
        out.add(CheckItem(CheckLevel.warning, '+48V is ON for unnamed channels',
            'These channels have phantom power on but no name, so the source is not documented.', ids));
      }
    }

    // 2. Same physical input used by several channels (info only: can be intentional).
    if (!u.contains(DataField.physical)) {
      final groups = <String, List<Strip>>{};
      for (final c in s.channels) {
        if (c.physical.isNotEmpty && c.physical != kNotRead) (groups[c.physical] ??= []).add(c);
      }
      for (final e in groups.entries) {
        final g = e.value;
        if (g.length < 2) continue;
        final linkedPair = g.length == 2 && g[0].link == 1 && g[1].link == 2;
        if (linkedPair) continue; // one source feeding a linked stereo pair is normal
        out.add(CheckItem(CheckLevel.info, 'Same input used by several channels',
            '${e.key} feeds more than one channel. This can be intentional (for example a split or duplicate signal).',
            [for (final c in g) c.id]));
      }
    }

    // 3. Named channel without any input source (info).
    if (!u.contains(DataField.physical)) {
      final ids = [for (final c in s.channels) if (c.name.trim().isNotEmpty && c.physical.isEmpty) c.id];
      if (ids.isNotEmpty) {
        out.add(CheckItem(CheckLevel.info, 'Named channels without an input source',
            'These channels have a name but no input source is assigned in the file.', ids));
      }
    }

    // 4. Data that could not be read.
    if (u.isNotEmpty) {
      final names = [for (final f in DataField.values) if (u.contains(f)) fieldLabel(f)];
      out.add(CheckItem(CheckLevel.info, 'Not read for this format',
          '${names.join(', ')} are never read from this file type, so the sheet shows "–" for them.'));
    }
    if (!u.contains(DataField.phantom)) {
      final unknown = [for (final c in s.channels) if (c.phantom == null && !c.phantomNa) c.id];
      if (unknown.isNotEmpty) {
        out.add(CheckItem(CheckLevel.info, '+48V state not available',
            'The file did not give a reliable +48V state for these channels (shown as "–").', unknown));
      }
    }
    return out;
  }
}
