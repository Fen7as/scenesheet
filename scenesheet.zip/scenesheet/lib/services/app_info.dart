import 'package:package_info_plus/package_info_plus.dart';

/// Version metadata read from the installed package (pubspec version name + build number).
class AppInfo {
  final String version, build;
  const AppInfo(this.version, this.build);
  static Future<AppInfo>? _cache;
  static Future<AppInfo> load() => _cache ??= _load();
  static void resetForTest() => _cache = null;
  static Future<AppInfo> _load() async {
    try {
      final p = await PackageInfo.fromPlatform();
      return AppInfo(p.version, p.buildNumber);
    } catch (_) {
      return const AppInfo('', '');
    }
  }
}
