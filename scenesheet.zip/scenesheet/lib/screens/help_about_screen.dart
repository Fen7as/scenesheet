import 'package:flutter/material.dart';
import '../services/app_info.dart';

class HelpAboutScreen extends StatelessWidget {
  const HelpAboutScreen({super.key});

  static const _help = <String, String>{
    'Importing a scene':
        'Tap Import Scene and pick a mixer scene file. The mixer is detected from the file contents and the file is copied into SceneSheet, so the original can be moved or deleted afterwards. After import, open Scene details to see what was read and what was not.',
    'Recent scenes and Scene Library':
        'Recent scenes on the home screen (and the clock icon for the full list) open the stored copy straight into the preview, most recently opened first. The bin icon deletes only SceneSheet\u2019s copy; your original file is never touched.',
    'Sections and channel data':
        'Choose which sections to include: Channel, Bus, Matrix, Aux, Main, FX. The Channel table shows low-cut, gate, dynamics, insert, +48V, groups and physical input where the file provides them.',
    'Data markers (\u2713, OFF, \u2013, N/A)':
        '\u2713 or ON = known on. OFF = confirmed off by the file. \u2013 = not read: the format or parser does not provide it, or the value is missing; it does NOT mean off. N/A = not applicable (for example +48V on an input that is not a mic preamp). Every page has a footnote naming the fields not read for that format. The +48V summary under the title lists only channels positively known to be ON.',
    'Compact and Text Size':
        'Compact packs complete tables efficiently and sizes the text automatically. With Compact off, Text Size \u2212/+ sets the size. Tables are never split across pages: a table and its heading move to the next page together. A3 gives more room than A4.',
    'Preview, export and sharing':
        'The preview shows the same pages that are exported; zoom and pan do not change the layout. The tune icon changes document, sections, format, Compact and Text Size and updates the preview; your last choices are remembered. Export PDF / Export Image save files. Share Scene Sheet sends PDF, PNG (current page or all pages) or CSV. Share Scene File (on the home screen) sends the original scene file stored in SceneSheet.',
    'CSV and Input List':
        'CSV is the channel list with the same values and markers as the table (UTF-8, opens non-English names correctly). Input List is a stage hand-off document: channels sorted by input socket where the file gives it, with blank columns for mic/source, stand, cable and notes. Channels whose socket is not reported are listed separately in channel order; nothing is invented.',
    'Pre-show checks and Compare scenes':
        'The checklist icon in the preview lists explainable issues: +48V ON on unnamed channels, an input shared by several channels (can be intentional), named channels without an input, and fields that could not be read. It is not a full validation. Compare (on the home screen) lists differences in channel names, patch, +48V and groups between two stored scenes; fields that either file does not expose are listed as not compared, never as changes.',
    'Supported formats and limits':
        'Behringer X32 / Midas M32 scenes (.scn): names, colours, links, low-cut, gate/dynamics on-off, inserts, groups, physical input and +48V for AES50-A inputs. +48V for Local and AES50-B inputs is not verified and shows \u2013.\n'
        'Yamaha QL (.CLF from QL Editor): input channel names and input patch only; everything else shows \u2013. Yamaha CL is detected but not supported yet.\n'
        'Soundcraft Ui24 (offline JSON and .uisnapshot): names, sources, +48V of hardware inputs, VCA/mute/subgroup tags and links; low-cut, gate, dynamics, inserts and colours are not read. Other Soundcraft families (Si, Vi) are detected but not supported yet.',
  };

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Help & About')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('SceneSheet', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Turns a mixer scene file into a printable scene sheet (PDF or PNG).'),
                const SizedBox(height: 6),
                FutureBuilder<AppInfo>(
                  future: AppInfo.load(),
                  builder: (c, s) {
                    final i = s.data;
                    if (i == null) return const Text('Version \u2026');
                    return Text(i.version.isEmpty ? 'Version unknown' : 'Version ${i.version} (build ${i.build})');
                  },
                ),
                const SizedBox(height: 6),
                const Text('Importing, parsing, preview and export work offline. The Android share sheet may hand files to apps that use the internet.'),
                const SizedBox(height: 8),
                const Text('By R. Fenhas', style: TextStyle(fontSize: 11, color: Color(0xFF9E9E9E))),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          for (final e in _help.entries)
            ExpansionTile(title: Text(e.key), childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12), children: [
              Align(alignment: Alignment.centerLeft, child: Text(e.value)),
            ]),
        ]),
      );
}
