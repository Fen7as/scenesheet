import 'package:flutter/material.dart';
import '../models/scene_model.dart';
import '../parsers/mixer_detector.dart';
import '../parsers/mixer_parser.dart';
import '../parsers/scene_parser.dart';
import '../services/file_import_service.dart';
import '../services/scene_library_service.dart';
import '../services/share_service.dart';
import 'library_screen.dart';
import 'preview_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Scene? scene;
  String? err;
  bool busy = false;
  MixerFile? lastFile;
  LibraryEntry? entry;
  SceneLibrary? _lib;
  final Set<Section> sel = {...Section.values};
  OutputFormat fmt = OutputFormat.a4;
  bool compact = false;
  double scale = 1.0;
  static const _minScale = 0.8, _maxScale = 1.6;
  static const _names = {
    Section.channel: 'Channel', Section.bus: 'Bus', Section.matrix: 'Matrix',
    Section.aux: 'Aux', Section.main: 'Main', Section.fx: 'FX',
  };

  Future<SceneLibrary> _library() async => _lib ??= await SceneLibrary.app();

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  /// Copies the imported file into app storage (the stored copy is what the library opens).
  Future<void> _store(MixerFile f) async {
    try {
      entry = await (await _library()).add(f);
    } catch (_) {
      entry = null;
      err = 'Could not store a copy of this scene.';
    }
  }

  Future<void> _import() async {
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final f = await FileImportService.pick();
      if (f != null) {
        lastFile = f;
        final s = SceneParser.parse(f);
        await _store(f);
        scene = s;
      }
    } on SceneException catch (e) {
      err = e.message;
      scene = null;
      entry = null;
    } catch (_) {
      err = 'Could not read the file.';
      scene = null;
      entry = null;
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _manual() async {
    final f = lastFile;
    if (f == null) return;
    final p = await showDialog<MixerParser>(
      context: context,
      builder: (c) => SimpleDialog(title: const Text('Choose mixer type'), children: [
        for (final m in MixerDetector.manualChoices)
          SimpleDialogOption(onPressed: () => Navigator.pop(c, m), child: Text(m.label)),
      ]),
    );
    if (p == null) return;
    try {
      final s = SceneParser.parse(f, force: p);
      err = null;
      await _store(f);
      scene = s;
    } on SceneException catch (e) {
      err = e.message;
      scene = null;
    } catch (_) {
      err = 'Could not read this mixer file.';
      scene = null;
    }
    if (mounted) setState(() {});
  }

  Future<void> _openLibrary() async {
    final r = await Navigator.push<OpenedScene>(
        context, MaterialPageRoute(builder: (_) => LibraryScreen(lib: _lib!)));
    if (r != null && mounted) {
      setState(() {
        scene = r.scene;
        entry = r.entry;
        lastFile = null;
        err = null;
      });
    }
  }

  Future<void> _showLibrary() async {
    await _library();
    await _openLibrary();
  }

  Future<void> _shareScene() async {
    final e = entry;
    if (e == null) return;
    try {
      await ShareService.shareFile((await _library()).fileOf(e));
    } catch (_) {
      if (mounted) _snack('Could not share the scene file.');
    }
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(children: [
          Expanded(child: Text(k)),
          Flexible(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600), textAlign: TextAlign.end)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final s = scene;
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          Align(
            alignment: Alignment.centerRight,
            child: IconButton(icon: const Icon(Icons.history), tooltip: 'Scene Library', onPressed: _showLibrary),
          ),
          Text('SceneSheet', style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Turn your mixer scene into a professional scene sheet.'),
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: busy ? null : _import,
            icon: const Icon(Icons.upload_file),
            label: const Text('Import Scene'),
          ),
          if (err != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(err!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ),
          if (err != null && lastFile != null)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(onPressed: _manual, child: const Text('Choose mixer type manually')),
            ),
          if (s != null) ...[
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  _row('Detected mixer', s.mixer),
                  _row('Model', s.model),
                  _row('Scene', s.name.isEmpty ? '(unnamed)' : s.name),
                  _row('File', s.fileName),
                  _row('Channels', '${s.channels.length}'),
                  _row('Buses', '${s.buses.length}'),
                  _row('Matrices', '${s.matrices.length}'),
                  _row('Auxes', '${s.auxes.length}'),
                  _row('FX', '${s.fxCount}'),
                ]),
              ),
            ),
            if (entry != null)
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                    onPressed: _shareScene, icon: const Icon(Icons.ios_share), label: const Text('Share Scene')),
              ),
            const SizedBox(height: 8),
            const Text('Sections to export', style: TextStyle(fontWeight: FontWeight.w600)),
            Wrap(spacing: 8, children: [
              for (final sec in Section.values)
                FilterChip(
                  label: Text(_names[sec]!),
                  selected: sel.contains(sec),
                  onSelected: (v) => setState(() => v ? sel.add(sec) : sel.remove(sec)),
                ),
            ]),
            Row(children: [
              TextButton(onPressed: () => setState(() => sel.addAll(Section.values)), child: const Text('Select All')),
              const Text('|'),
              TextButton(onPressed: () => setState(sel.clear), child: const Text('Clear All')),
            ]),
            const SizedBox(height: 8),
            const Text('Output Format', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            SegmentedButton<OutputFormat>(
              segments: const [
                ButtonSegment(value: OutputFormat.screen, label: Text('Screen')),
                ButtonSegment(value: OutputFormat.a4, label: Text('A4')),
                ButtonSegment(value: OutputFormat.a3, label: Text('A3')),
              ],
              selected: {fmt},
              onSelectionChanged: (v) => setState(() => fmt = v.first),
            ),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text('Compact'),
              value: compact,
              onChanged: (v) => setState(() => compact = v ?? false),
            ),
            Row(children: [
              Text('Text Size', style: TextStyle(color: compact ? Theme.of(context).disabledColor : null)),
              IconButton(
                icon: const Icon(Icons.remove),
                tooltip: 'Text Size -',
                onPressed: compact || scale <= _minScale + 0.01
                    ? null
                    : () => setState(() => scale = double.parse((scale - 0.1).toStringAsFixed(1))),
              ),
              Text(compact ? 'Auto' : '${(scale * 100).round()}%'),
              IconButton(
                icon: const Icon(Icons.add),
                tooltip: 'Text Size +',
                onPressed: compact || scale >= _maxScale - 0.01
                    ? null
                    : () => setState(() => scale = double.parse((scale + 0.1).toStringAsFixed(1))),
              ),
            ]),
            const SizedBox(height: 8),
            FilledButton.tonalIcon(
              onPressed: sel.isEmpty
                  ? null
                  : () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => PreviewScreen(
                              scene: s,
                              options: SheetOptions(
                                  sections: Set.of(sel), format: fmt, compact: compact, textScale: scale)))),
              icon: const Icon(Icons.description_outlined),
              label: const Text('Generate Scene Sheet'),
            ),
          ],
        ]),
      ),
    );
  }
}
