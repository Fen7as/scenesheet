import 'package:flutter/material.dart';
import '../models/scene_model.dart';
import '../parsers/mixer_parser.dart';
import '../parsers/scene_parser.dart';
import '../services/file_import_service.dart';
import 'preview_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Scene? scene;
  String? err;
  bool busy = false;
  final Set<Section> sel = {...Section.values};
  OutputFormat fmt = OutputFormat.a4;
  static const _names = {
    Section.channel: 'Channel', Section.bus: 'Bus', Section.matrix: 'Matrix',
    Section.aux: 'Aux', Section.main: 'Main', Section.fx: 'FX',
  };

  Future<void> _import() async {
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final f = await FileImportService.pick();
      if (f != null) scene = SceneParser.parse(f.text, f.name);
    } on SceneException catch (e) {
      err = e.message;
      scene = null;
    } catch (_) {
      err = 'Could not read the file.';
      scene = null;
    }
    if (mounted) setState(() => busy = false);
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(children: [
          Expanded(child: Text(k)),
          Flexible(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600), textAlign: TextAlign.end)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final s = scene;
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 24),
          Text('SceneSheet', style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Turn your mixer scene into a professional scene sheet.'),
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: busy ? null : _import,
            icon: const Icon(Icons.upload_file),
            label: const Text('Import Scene'),
          ),
          if (err != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(err!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ),
          if (s != null) ...[
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  _row('Detected mixer', s.mixer),
                  _row('Model', s.model),
                  _row('Scene', s.name.isEmpty ? '(unnamed)' : s.name),
                  _row('File', s.fileName),
                  _row('Channels', '${s.channels.length}'),
                  _row('Buses', '${s.buses.length}'),
                  _row('Matrices', '${s.matrices.length}'),
                  _row('Auxes', '${s.auxes.length}'),
                  _row('FX', '${s.fxSlots.length + s.fxReturns.length ~/ 2}'),
                ]),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Sections to export', style: TextStyle(fontWeight: FontWeight.w600)),
            Wrap(spacing: 8, children: [
              for (final sec in Section.values)
                FilterChip(
                  label: Text(_names[sec]!),
                  selected: sel.contains(sec),
                  onSelected: (v) => setState(() => v ? sel.add(sec) : sel.remove(sec)),
                ),
            ]),
            Row(children: [
              TextButton(onPressed: () => setState(() => sel.addAll(Section.values)), child: const Text('Select All')),
              const Text('|'),
              TextButton(onPressed: () => setState(sel.clear), child: const Text('Clear All')),
            ]),
            const SizedBox(height: 8),
            const Text('Output Format', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            SegmentedButton<OutputFormat>(
              segments: const [
                ButtonSegment(value: OutputFormat.screen, label: Text('Screen')),
                ButtonSegment(value: OutputFormat.a4, label: Text('A4 Landscape')),
              ],
              selected: {fmt},
              onSelectionChanged: (v) => setState(() => fmt = v.first),
            ),
            const SizedBox(height: 16),
            FilledButton.tonalIcon(
              onPressed: sel.isEmpty
                  ? null
                  : () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => PreviewScreen(
                              scene: s, options: SheetOptions(sections: Set.of(sel), format: fmt)))),
              icon: const Icon(Icons.description_outlined),
              label: const Text('Generate Scene Sheet'),
            ),
          ],
        ]),
      ),
    );
  }
}
