import 'package:flutter/material.dart';
import '../models/scene_model.dart';
import '../parsers/mixer_detector.dart';
import '../parsers/mixer_parser.dart';
import '../parsers/scene_parser.dart';
import '../services/file_import_service.dart';
import '../services/options_store.dart';
import '../services/scene_library_service.dart';
import '../services/share_service.dart';
import '../widgets/app_signature.dart';
import '../widgets/scene_details.dart';
import 'compare_screen.dart';
import 'help_about_screen.dart';
import 'library_screen.dart';
import 'preview_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Scene? scene;
  String? err;
  bool busy = false;
  MixerFile? lastFile;
  LibraryEntry? entry;
  SceneLibrary? _lib;
  OptionsStore? _store;
  SheetOptions opts = SheetOptions(sections: {...Section.values});
  List<LibraryEntry> recent = [];
  static const _recentShown = 5;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      _lib = await SceneLibrary.app();
      _store = await OptionsStore.app();
      final saved = await _store!.load();
      if (saved != null) opts = saved;
      await _refresh();
    } catch (_) {/* storage unavailable: app still works for one-off imports */}
  }

  Future<void> _refresh() async {
    final l = await _lib?.list();
    if (l != null && mounted) setState(() => recent = l);
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  /// Copies the imported file into app storage (the stored copy is what the library opens).
  Future<void> _storeCopy(MixerFile f) async {
    try {
      entry = await _lib?.add(f);
    } catch (_) {
      entry = null;
      err = 'Could not store a copy of this scene.';
    }
  }

  Future<void> _import() async {
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final f = await FileImportService.pick();
      if (f != null) {
        lastFile = f;
        final s = SceneParser.parse(f);
        await _storeCopy(f);
        scene = s;
      }
    } on SceneException catch (e) {
      err = e.message;
      scene = null;
      entry = null;
    } catch (_) {
      err = 'Could not read this mixer file.';
      scene = null;
      entry = null;
    }
    if (mounted) setState(() => busy = false);
    _refresh();
  }

  Future<void> _manual() async {
    final f = lastFile;
    if (f == null) return;
    final p = await showDialog<MixerParser>(
      context: context,
      builder: (c) => SimpleDialog(title: const Text('Choose mixer type'), children: [
        for (final m in MixerDetector.manualChoices)
          SimpleDialogOption(onPressed: () => Navigator.pop(c, m), child: Text(m.label)),
      ]),
    );
    if (p == null) return;
    try {
      final s = SceneParser.parse(f, force: p);
      err = null;
      await _storeCopy(f);
      scene = s;
    } on SceneException catch (e) {
      err = e.message;
      scene = null;
    } catch (_) {
      err = 'Could not read this mixer file.';
      scene = null;
    }
    if (mounted) setState(() {});
    _refresh();
  }

  /// Opens the Preview with the last-used options, adapted to what this scene actually contains.
  Future<void> _preview(Scene s) async {
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => PreviewScreen(
                  scene: s,
                  options: opts.sanitizedFor(s),
                  onOptionsChanged: (o) {
                    opts = o;
                    _store?.save(o);
                  },
                )));
    _refresh();
  }

  /// Recent scene -> stored copy -> straight into Preview.
  Future<void> _openEntry(LibraryEntry e) async {
    setState(() {
      busy = true;
      err = null;
    });
    Scene? s;
    try {
      s = SceneParser.parse(await _lib!.open(e));
      scene = s;
      entry = e;
      lastFile = null;
    } on SceneException catch (x) {
      err = x.message;
    } catch (_) {
      err = 'Could not open this scene.';
    }
    if (mounted) setState(() => busy = false);
    if (s != null && mounted) await _preview(s);
    _refresh();
  }

  Future<void> _showLibrary() async {
    final lib = _lib;
    if (lib == null) return;
    final r = await Navigator.push<OpenedScene>(context, MaterialPageRoute(builder: (_) => LibraryScreen(lib: lib)));
    if (r != null && mounted) {
      setState(() {
        scene = r.scene;
        entry = r.entry;
        lastFile = null;
        err = null;
      });
      await _preview(r.scene);
    }
    _refresh();
  }

  Future<void> _shareScene() async {
    final e = entry;
    if (e == null || _lib == null) return;
    try {
      await ShareService.shareFile(_lib!.fileOf(e));
    } catch (_) {
      if (mounted) _snack('Could not share the scene file.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = scene;
    return Scaffold(
      bottomNavigationBar: const SafeArea(child: AppSignature(showVersion: true)),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          Align(
            alignment: Alignment.centerRight,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                  icon: const Icon(Icons.info_outline),
                  tooltip: 'Help & About',
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpAboutScreen()))),
              IconButton(icon: const Icon(Icons.history), tooltip: 'Scene Library', onPressed: _showLibrary),
            ]),
          ),
          Text('SceneSheet', style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Turn your mixer scene into a professional scene sheet.'),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: busy ? null : _import,
            icon: const Icon(Icons.upload_file),
            label: const Text('Import Scene'),
          ),
          if (busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator(minHeight: 2)),
          if (err != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(err!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ),
          if (err != null && lastFile != null)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(onPressed: _manual, child: const Text('Choose mixer type manually')),
            ),
          if (s != null) ...[
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.name.isEmpty ? s.fileName : s.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  Text(s.mixer),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                        child: FilledButton.icon(
                            onPressed: () => _preview(s), icon: const Icon(Icons.description_outlined), label: const Text('Open Preview'))),
                    if (entry != null) ...[
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                          onPressed: _shareScene, icon: const Icon(Icons.ios_share), label: const Text('Share Scene File')),
                    ],
                  ]),
                  ExpansionTile(
                    tilePadding: EdgeInsets.zero,
                    initiallyExpanded: true,
                    title: const Text('Scene details'),
                    children: [Align(alignment: Alignment.centerLeft, child: SceneDetails(scene: s))],
                  ),
                ]),
              ),
            ),
          ],
          const SizedBox(height: 20),
          Row(children: [
            const Expanded(child: Text('Recent scenes', style: TextStyle(fontWeight: FontWeight.w600))),
            if (recent.length >= 2)
              TextButton(
                  onPressed: _lib == null
                      ? null
                      : () => Navigator.push(context, MaterialPageRoute(builder: (_) => CompareScreen(lib: _lib!))),
                  child: const Text('Compare')),
            if (recent.length > _recentShown) TextButton(onPressed: _showLibrary, child: const Text('All scenes')),
          ]),
          if (recent.isEmpty) const Text('No scenes yet. Import a scene to get started.'),
          for (final e in recent.take(_recentShown))
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('Last opened: ${formatLastOpened(e.lastOpened)}'),
              onTap: busy ? null : () => _openEntry(e),
            ),
        ]),
      ),
    );
  }
}
