import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/scene_model.dart';
import '../services/checks_service.dart';
import '../services/image_export_service.dart';
import '../services/pdf_export_service.dart';
import '../services/share_dispatch.dart';
import '../services/share_service.dart';
import '../widgets/app_signature.dart';
import '../widgets/checks_sheet.dart';
import '../widgets/scene_details.dart';
import '../widgets/scene_page_viewer.dart';
import '../widgets/sheet_options_panel.dart';

class PreviewScreen extends StatefulWidget {
  final Scene scene;
  final SheetOptions options;
  final ValueChanged<SheetOptions>? onOptionsChanged;
  const PreviewScreen({super.key, required this.scene, required this.options, this.onOptionsChanged});
  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  late SheetOptions opts = widget.options;
  late final List<CheckItem> checks = ChecksService.run(widget.scene);
  Uint8List? pdf;
  List<Uint8List> pages = [];
  String? err;
  bool busy = false;
  int _gen = 0, _page = 0;

  String get _base =>
      ShareService.safeName(widget.scene.name.isEmpty ? widget.scene.fileName : widget.scene.name);

  @override
  void initState() {
    super.initState();
    _generate();
  }

  /// Rebuilds the PDF and its page rasters; stale results of older requests are ignored.
  Future<void> _generate() async {
    final id = ++_gen;
    if (!opts.inputList && opts.sections.isEmpty) {
      setState(() {
        pdf = null;
        pages = [];
        busy = false;
        err = 'Select at least one section.';
      });
      return;
    }
    setState(() => busy = true);
    try {
      final b = await PdfExportService.build(widget.scene, opts);
      final p = await ImageExportService.render(b);
      if (!mounted || id != _gen) return;
      setState(() {
        pdf = b;
        pages = p;
        busy = false;
        err = null;
      });
    } catch (e) {
      if (!mounted || id != _gen) return;
      setState(() {
        pdf = null;
        pages = [];
        busy = false;
        err = e is SheetLayoutException ? e.message : 'Could not generate the scene sheet.';
      });
    }
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _run(Future<String?> Function() f) async {
    try {
      final msg = await f();
      if (msg != null && mounted) _snack(msg);
    } catch (_) {
      if (mounted) _snack('Export failed.');
    }
  }

  Future<String?> _savePdf() async {
    final r = await FilePicker.platform.saveFile(dialogTitle: 'Save PDF', fileName: '$_base.pdf', bytes: pdf);
    return r == null ? null : 'PDF saved';
  }

  Future<String?> _saveImages() async {
    var saved = 0;
    for (var i = 0; i < pages.length; i++) {
      final r = await FilePicker.platform
          .saveFile(dialogTitle: 'Save image', fileName: '${_base}_p${i + 1}.png', bytes: pages[i]);
      if (r != null) saved++;
    }
    return saved == 0 ? null : 'Saved $saved image(s)';
  }

  /// Share the generated Scene Sheet (not the scene file): PDF, PNG current page / all pages, or CSV.
  Future<void> _shareSheet() async {
    final n = pages.length;
    final choice = await showModalBottomSheet<ShareChoice>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const ListTile(title: Text('Share Scene Sheet', style: TextStyle(fontWeight: FontWeight.w600))),
          ListTile(
              leading: const Icon(Icons.picture_as_pdf),
              title: Text(n > 1 ? 'PDF (all $n pages)' : 'PDF'),
              onTap: () => Navigator.pop(c, ShareChoice.pdf)),
          ListTile(
              leading: const Icon(Icons.image),
              title: Text(n > 1 ? 'PNG \u2013 current page (${_page + 1} of $n)' : 'PNG'),
              onTap: () => Navigator.pop(c, ShareChoice.pngCurrent)),
          if (n > 1)
            ListTile(
                leading: const Icon(Icons.collections),
                title: Text('PNG \u2013 all $n pages'),
                onTap: () => Navigator.pop(c, ShareChoice.pngAll)),
          ListTile(
              leading: const Icon(Icons.table_chart),
              title: const Text('CSV \u2013 channel list'),
              onTap: () => Navigator.pop(c, ShareChoice.csv)),
        ]),
      ),
    );
    if (choice == null) return;
    await _run(() async {
      await dispatchShare(choice,
          scene: widget.scene, pdf: pdf, pages: pages, base: _base, currentPage: _page);
      return null;
    });
  }

  void _options() => showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (c) => StatefulBuilder(
          builder: (c, setSheet) => SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: SheetOptionsPanel(
                options: opts,
                onChanged: (o) {
                  setState(() => opts = o);
                  setSheet(() {});
                  widget.onOptionsChanged?.call(o); // remember last-used options
                  _generate(); // live preview update
                },
              ),
            ),
          ),
        ),
      );

  void _details() => showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (c) => SafeArea(
            child: SingleChildScrollView(padding: const EdgeInsets.all(16), child: SceneDetails(scene: widget.scene))),
      );

  @override
  Widget build(BuildContext context) {
    final ready = pdf != null && !busy;
    final warnings = checks.where((c) => c.level == CheckLevel.warning).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Preview'),
        actions: [
          IconButton(
              icon: Badge(
                  isLabelVisible: warnings > 0, label: Text('$warnings'), child: const Icon(Icons.fact_check_outlined)),
              tooltip: 'Pre-show checks',
              onPressed: () => showChecksSheet(context, checks)),
          IconButton(icon: const Icon(Icons.info_outline), tooltip: 'Scene details', onPressed: _details),
          IconButton(icon: const Icon(Icons.tune), tooltip: 'Layout options', onPressed: _options),
        ],
      ),
      body: err != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(err!, textAlign: TextAlign.center)))
          : pages.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : ScenePageViewer(pages: pages, busy: busy, onPageChanged: (p) => _page = p),
      bottomNavigationBar: SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(child: OutlinedButton(onPressed: ready ? () => _run(_savePdf) : null, child: const Text('Export PDF'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton(onPressed: ready ? () => _run(_saveImages) : null, child: const Text('Export Image'))),
              const SizedBox(width: 8),
              Expanded(child: FilledButton(onPressed: ready ? _shareSheet : null, child: const Text('Share'))),
            ]),
          ),
          const AppSignature(),
        ]),
      ),
    );
  }
}
