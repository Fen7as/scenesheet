import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../models/scene_model.dart';
import '../services/image_export_service.dart';
import '../services/pdf_export_service.dart';
import '../services/share_service.dart';
import '../widgets/app_signature.dart';

class PreviewScreen extends StatefulWidget {
  final Scene scene;
  final SheetOptions options;
  const PreviewScreen({super.key, required this.scene, required this.options});
  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  Uint8List? pdf;
  List<Uint8List> pages = [];
  String? err;

  String get _base => ShareService.safeName(
      widget.scene.name.isEmpty ? widget.scene.fileName : widget.scene.name);

  @override
  void initState() {
    super.initState();
    _gen();
  }

  Future<void> _gen() async {
    try {
      final b = await PdfExportService.build(widget.scene, widget.options);
      final p = await ImageExportService.render(b);
      if (mounted) setState(() {
            pdf = b;
            pages = p;
          });
    } catch (e) {
      if (mounted) setState(() => err = e is SheetLayoutException ? e.message : 'Could not generate the scene sheet.');
    }
  }

  Future<void> _run(Future<String?> Function() f) async {
    try {
      final msg = await f();
      if (msg != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Export failed.')));
      }
    }
  }

  Future<String?> _savePdf() async {
    final r = await FilePicker.platform
        .saveFile(dialogTitle: 'Save PDF', fileName: '$_base.pdf', bytes: pdf);
    return r == null ? null : 'PDF saved';
  }

  Future<String?> _saveImages() async {
    var saved = 0;
    for (var i = 0; i < pages.length; i++) {
      final r = await FilePicker.platform.saveFile(
          dialogTitle: 'Save image', fileName: '${_base}_p${i + 1}.png', bytes: pages[i]);
      if (r != null) saved++;
    }
    return saved == 0 ? null : 'Saved $saved image(s)';
  }

  @override
  Widget build(BuildContext context) {
    final ready = pdf != null;
    return Scaffold(
      appBar: AppBar(title: const Text('Scene Sheet')),
      body: err != null
          ? Center(child: Text(err!))
          : !ready
              ? const Center(child: CircularProgressIndicator())
              : ListView(padding: const EdgeInsets.all(8), children: [
                  for (final p in pages)
                    Card(
                      clipBehavior: Clip.antiAlias,
                      child: InteractiveViewer(minScale: 1, maxScale: 6, child: Image.memory(p)),
                    ),
                ]),
      bottomNavigationBar: SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
         Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: OutlinedButton(onPressed: ready ? () => _run(_savePdf) : null, child: const Text('Export PDF'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: ready ? () => _run(_saveImages) : null, child: const Text('Export Image'))),
            const SizedBox(width: 8),
            Expanded(
                child: FilledButton(
                    onPressed: ready ? () => _run(() async { await ShareService.share(pdf!, pages, _base); return null; }) : null,
                    child: const Text('Share'))),
          ]),
        ),
        const AppSignature(),
      ]),
      ),
    );
  }
}
