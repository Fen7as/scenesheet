import 'package:flutter/material.dart';
import '../parsers/mixer_parser.dart';
import '../parsers/scene_parser.dart';
import '../services/compare_service.dart';
import '../services/scene_library_service.dart';

/// Read-only comparison of two stored scenes (names, patch, +48V, groups where both files expose them).
class CompareScreen extends StatefulWidget {
  final SceneLibrary lib;
  const CompareScreen({super.key, required this.lib});
  @override
  State<CompareScreen> createState() => _CompareScreenState();
}

class _CompareScreenState extends State<CompareScreen> {
  List<LibraryEntry> items = [];
  LibraryEntry? a, b;
  CompareResult? result;
  bool busy = false;
  String? err;

  @override
  void initState() {
    super.initState();
    widget.lib.list().then((l) {
      if (mounted) setState(() => items = l);
    });
  }

  Future<void> _compare() async {
    setState(() {
      busy = true;
      err = null;
      result = null;
    });
    try {
      final sa = SceneParser.parse(await widget.lib.peek(a!));
      final sb = SceneParser.parse(await widget.lib.peek(b!));
      result = CompareService.compare(sa, sb);
    } on SceneException catch (e) {
      err = e.message;
    } catch (_) {
      err = 'Could not compare these scenes.';
    }
    if (mounted) setState(() => busy = false);
  }

  Widget _pick(String label, LibraryEntry? v, ValueChanged<LibraryEntry?> on) => InputDecorator(
        decoration: InputDecoration(labelText: label),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<LibraryEntry>(
            value: v,
            isExpanded: true,
            items: [
              for (final e in items) DropdownMenuItem(value: e, child: Text(e.name, overflow: TextOverflow.ellipsis)),
            ],
            onChanged: on,
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final r = result;
    return Scaffold(
      appBar: AppBar(title: const Text('Compare scenes')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _pick('Scene A', a, (v) => setState(() => a = v)),
        const SizedBox(height: 8),
        _pick('Scene B', b, (v) => setState(() => b = v)),
        const SizedBox(height: 12),
        FilledButton(
            onPressed: busy || a == null || b == null || a == b ? null : _compare, child: const Text('Compare')),
        if (busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
        if (err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err!)),
        if (r != null) ...[
          const SizedBox(height: 12),
          Text(r.summary),
          if (r.onlyInA.isNotEmpty) Text('Only in ${r.nameA}: channels ${r.onlyInA.join(', ')}'),
          if (r.onlyInB.isNotEmpty) Text('Only in ${r.nameB}: channels ${r.onlyInB.join(', ')}'),
          const Divider(),
          for (final d in r.diffs)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('Ch ${d.channel} \u00b7 ${d.field}'),
              subtitle: Text('${r.nameA}: ${d.a}\n${r.nameB}: ${d.b}'),
            ),
        ],
      ]),
    );
  }
}
