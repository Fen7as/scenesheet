import 'package:flutter/material.dart';
import '../models/scene_model.dart';
import '../parsers/mixer_parser.dart';
import '../parsers/scene_parser.dart';
import '../services/scene_library_service.dart';

class OpenedScene {
  final LibraryEntry entry;
  final Scene scene;
  OpenedScene(this.entry, this.scene);
}

class LibraryScreen extends StatefulWidget {
  final SceneLibrary lib;
  const LibraryScreen({super.key, required this.lib});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  List<LibraryEntry>? items;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await widget.lib.list();
    if (mounted) setState(() => items = l);
  }

  static const _m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  String _fmt(DateTime d) =>
      '${d.day} ${_m[d.month - 1]} ${d.year}, ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _open(LibraryEntry e) async {
    try {
      final f = await widget.lib.open(e);
      final s = SceneParser.parse(f);
      if (mounted) Navigator.pop(context, OpenedScene(e, s));
    } on SceneException catch (x) {
      _snack(x.message);
      _load();
    } catch (_) {
      _snack('Could not open this scene.');
    }
  }

  Future<void> _delete(LibraryEntry e) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Delete "${e.name}" from SceneSheet?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await widget.lib.delete(e);
    } catch (_) {
      _snack('Could not delete this scene.');
    }
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final l = items;
    return Scaffold(
      appBar: AppBar(title: const Text('Scene Library')),
      body: l == null
          ? const Center(child: CircularProgressIndicator())
          : l.isEmpty
              ? const Center(child: Text('No scenes yet.'))
              : ListView.builder(
                  itemCount: l.length,
                  itemBuilder: (c, i) => ListTile(
                    title: Text(l[i].name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('Last opened: ${_fmt(l[i].lastOpened)}'),
                    trailing: IconButton(
                        icon: const Icon(Icons.delete_outline), tooltip: 'Delete', onPressed: () => _delete(l[i])),
                    onTap: () => _open(l[i]),
                  ),
                ),
    );
  }
}
