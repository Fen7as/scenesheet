/// Fields a parser may or may not be able to read from a given file format.
enum DataField { lowcut, gate, dyn, insert, phantom, link, grp, physical }

/// Marker for "not read from this file" (distinct from OFF, empty or N/A).
const kNotRead = '–';

String fieldLabel(DataField f) => const {
      DataField.lowcut: 'low-cut',
      DataField.gate: 'gate',
      DataField.dyn: 'dyn',
      DataField.insert: 'insert',
      DataField.phantom: '+48V',
      DataField.link: 'link',
      DataField.grp: 'grp',
      DataField.physical: 'physical',
    }[f]!;

/// One label for every tri-state value:
/// not read (format never exposes it, or this value is missing) -> "–",
/// not applicable -> "N/A", known -> [on]/[off]. A missing value is never shown as OFF.
String stateLabel(bool? v, {bool unread = false, bool na = false, String on = 'ON', String off = 'OFF'}) {
  if (unread) return kNotRead;
  if (na) return 'N/A';
  if (v == null) return kNotRead;
  return v ? on : off;
}

/// One row of any section (channel, bus, matrix, aux, main, FX).
/// bool? fields: true = ON, false = confirmed OFF, null = state not read.
class Strip {
  final String id, name, color, insert, physical, device, src, grp;
  final int link; // 0 none, 1 first of linked pair, 2 second
  final bool? lowcut, gate, dyn, phantom;
  final bool insertOn;
  /// Phantom power does not apply (source is not a mic preamp, or the channel is unpatched).
  final bool phantomNa;
  /// Sortable stagebox/input-socket rank when the file reliably gives one (null = unknown).
  final int? portRank;
  const Strip({
    required this.id,
    this.name = '',
    this.color = 'OFF',
    this.link = 0,
    this.lowcut,
    this.gate,
    this.dyn,
    this.phantom,
    this.phantomNa = false,
    this.portRank,
    this.insert = '',
    this.insertOn = false,
    this.physical = '',
    this.device = '',
    this.src = '',
    this.grp = '',
  });
}

enum Section { channel, bus, matrix, aux, main, fx }

enum OutputFormat { screen, a4, a3 }

class SheetOptions {
  final Set<Section> sections;
  final OutputFormat format;
  /// Smart auto layout (auto text size); when true [textScale] is ignored.
  final bool compact;
  /// Manual text size multiplier (used when [compact] is false).
  final double textScale;
  /// Input List document (stage hand-off) instead of the normal Scene Sheet.
  final bool inputList;
  const SheetOptions({
    required this.sections,
    this.format = OutputFormat.a4,
    this.compact = false,
    this.textScale = 1.0,
    this.inputList = false,
  });

  SheetOptions copyWith({Set<Section>? sections, OutputFormat? format, bool? compact, double? textScale, bool? inputList}) =>
      SheetOptions(
          sections: sections ?? this.sections,
          format: format ?? this.format,
          compact: compact ?? this.compact,
          textScale: textScale ?? this.textScale,
          inputList: inputList ?? this.inputList);

  Map<String, dynamic> toJson() => {
        'sections': [for (final s in sections) s.name],
        'format': format.name,
        'compact': compact,
        'textScale': textScale,
        'inputList': inputList,
      };

  static SheetOptions? fromJson(Object? j) {
    try {
      final m = j as Map<String, dynamic>;
      final names = (m['sections'] as List).map((e) => '$e').toSet();
      final fmt = OutputFormat.values.firstWhere((f) => f.name == m['format'], orElse: () => OutputFormat.a4);
      final scale = ((m['textScale'] as num?)?.toDouble() ?? 1.0).clamp(0.8, 1.6).toDouble();
      return SheetOptions(
          sections: Section.values.where((s) => names.contains(s.name)).toSet(),
          format: fmt,
          compact: m['compact'] == true,
          textScale: scale,
          inputList: m['inputList'] == true);
    } catch (_) {
      return null;
    }
  }

  /// Drops saved sections this scene does not have (never leaves an empty selection).
  SheetOptions sanitizedFor(Scene s) {
    final avail = <Section>{
      if (s.channels.isNotEmpty) Section.channel,
      if (s.buses.isNotEmpty) Section.bus,
      if (s.matrices.isNotEmpty) Section.matrix,
      if (s.auxes.isNotEmpty) Section.aux,
      if (s.main.isNotEmpty) Section.main,
      if (s.fxReturns.isNotEmpty || s.fxSlots.isNotEmpty) Section.fx,
    };
    var secs = sections.intersection(avail);
    if (secs.isEmpty) secs = avail;
    return SheetOptions(
        sections: secs,
        format: format,
        compact: compact,
        textScale: textScale.clamp(0.8, 1.6).toDouble(),
        inputList: inputList);
  }
}

class Scene {
  final String mixer, model, name, version;
  String fileName = '';
  /// X32-style FX returns come as L/R pairs; other mixers list one row per return.
  final bool fxStereo;
  int get fxCount => fxSlots.length + (fxStereo ? fxReturns.length ~/ 2 : fxReturns.length);
  final List<Strip> channels, buses, matrices, auxes, main, fxReturns, fxSlots;
  /// Fields this FORMAT/parser never reads: shown as "–" everywhere, never as OFF/empty.
  final Set<DataField> unread;
  /// Plain-language import diagnostics (what was read / what was not).
  final List<String> read, notRead;
  Scene({
    required this.mixer,
    required this.model,
    required this.name,
    required this.version,
    required this.channels,
    required this.buses,
    required this.matrices,
    required this.auxes,
    required this.main,
    required this.fxReturns,
    required this.fxSlots,
    this.fxStereo = true,
    this.unread = const {},
    this.read = const [],
    this.notRead = const [],
  });
}

/// "+48V ON: 25, 26" built from the same channel data as the table.
String phantomSummary(Scene s) {
  if (s.channels.isEmpty) return '';
  if (s.unread.contains(DataField.phantom)) return '+48V: not read for this format';
  final on = [for (final c in s.channels) if (c.phantom == true) c.id];
  final unknown = s.channels.where((c) => c.phantom == null && !c.phantomNa).length;
  var t = '+48V ON: ${on.isEmpty ? 'none' : on.join(', ')}';
  if (unknown > 0) t += ' (state unknown for $unknown ch)';
  return t;
}
