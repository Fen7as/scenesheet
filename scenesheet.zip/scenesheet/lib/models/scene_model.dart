/// One row of any section (channel, bus, matrix, aux, main, FX).
class Strip {
  final String id, name, color, insert, physical, device, src, grp;
  final int link; // 0 none, 1 first of linked pair, 2 second
  final bool? lowcut, gate, dyn, phantom;
  final bool insertOn;
  const Strip({
    required this.id,
    this.name = '',
    this.color = 'OFF',
    this.link = 0,
    this.lowcut,
    this.gate,
    this.dyn,
    this.phantom,
    this.insert = '',
    this.insertOn = false,
    this.physical = '',
    this.device = '',
    this.src = '',
    this.grp = '',
  });
}

enum Section { channel, bus, matrix, aux, main, fx }

enum OutputFormat { screen, a4, a3 }

class SheetOptions {
  final Set<Section> sections;
  final OutputFormat format;
  /// Smart auto layout (auto text size); when true [textScale] is ignored.
  final bool compact;
  /// Manual text size multiplier (used when [compact] is false).
  final double textScale;
  const SheetOptions({required this.sections, this.format = OutputFormat.a4, this.compact = false, this.textScale = 1.0});
}

class Scene {
  final String mixer, model, name, version;
  String fileName = '';
  /// X32-style FX returns come as L/R pairs; other mixers list one row per return.
  final bool fxStereo;
  int get fxCount => fxSlots.length + (fxStereo ? fxReturns.length ~/ 2 : fxReturns.length);
  final List<Strip> channels, buses, matrices, auxes, main, fxReturns, fxSlots;
  Scene({
    required this.mixer,
    required this.model,
    required this.name,
    required this.version,
    required this.channels,
    required this.buses,
    required this.matrices,
    required this.auxes,
    required this.main,
    required this.fxReturns,
    required this.fxSlots,
    this.fxStereo = true,
  });
}
