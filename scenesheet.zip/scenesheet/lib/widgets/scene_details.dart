import 'package:flutter/material.dart';
import '../models/scene_model.dart';

/// Detected format, counts and what was / was not read from the file.
class SceneDetails extends StatelessWidget {
  final Scene scene;
  const SceneDetails({super.key, required this.scene});

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(children: [
          Expanded(child: Text(k)),
          Flexible(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600), textAlign: TextAlign.end)),
        ]),
      );

  Widget _list(BuildContext c, String title, List<String> items) => items.isEmpty
      ? const SizedBox.shrink()
      : Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            for (final i in items) Text('\u2022 $i'),
          ]),
        );

  @override
  Widget build(BuildContext context) {
    final s = scene;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _row('Detected mixer', s.mixer),
      _row('Model', s.model),
      _row('Scene', s.name.isEmpty ? '(unnamed)' : s.name),
      _row('File', s.fileName),
      _row('Channels', '${s.channels.length}'),
      _row('Buses', '${s.buses.length}'),
      _row('Matrices', '${s.matrices.length}'),
      _row('Auxes', '${s.auxes.length}'),
      _row('FX', '${s.fxCount}'),
      _list(context, 'Read from this file', s.read),
      _list(context, 'Not read (shown as \u201c\u2013\u201d or left out)', s.notRead),
    ]);
  }
}
