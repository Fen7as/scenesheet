import 'package:flutter/material.dart';
import '../models/scene_model.dart';

/// Document / Sections / Output Format / Compact / Text Size. Shared by the live Preview.
class SheetOptionsPanel extends StatelessWidget {
  final SheetOptions options;
  final ValueChanged<SheetOptions> onChanged;
  const SheetOptionsPanel({super.key, required this.options, required this.onChanged});

  static const minScale = 0.8, maxScale = 1.6;
  static const _names = {
    Section.channel: 'Channel', Section.bus: 'Bus', Section.matrix: 'Matrix',
    Section.aux: 'Aux', Section.main: 'Main', Section.fx: 'FX',
  };

  @override
  Widget build(BuildContext context) {
    final o = options, compact = o.compact;
    double step(double d) => double.parse((o.textScale + d).toStringAsFixed(1));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Document', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 4),
      SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: false, label: Text('Scene Sheet')),
          ButtonSegment(value: true, label: Text('Input List')),
        ],
        selected: {o.inputList},
        onSelectionChanged: (v) => onChanged(o.copyWith(inputList: v.first)),
      ),
      const SizedBox(height: 8),
      if (o.inputList)
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: Text('Input List: channels sorted by input socket, with blank columns for hand-written notes. '
              'Sections and Compact do not apply.'),
        )
      else ...[
        const Text('Sections to export', style: TextStyle(fontWeight: FontWeight.w600)),
        Wrap(spacing: 8, children: [
          for (final sec in Section.values)
            FilterChip(
              label: Text(_names[sec]!),
              selected: o.sections.contains(sec),
              onSelected: (v) => onChanged(o.copyWith(sections: v ? {...o.sections, sec} : ({...o.sections}..remove(sec)))),
            ),
        ]),
        Row(children: [
          TextButton(onPressed: () => onChanged(o.copyWith(sections: {...Section.values})), child: const Text('Select All')),
          const Text('|'),
          TextButton(onPressed: () => onChanged(o.copyWith(sections: <Section>{})), child: const Text('Clear All')),
        ]),
        const SizedBox(height: 8),
      ],
      const Text('Output Format', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 4),
      SegmentedButton<OutputFormat>(
        segments: const [
          ButtonSegment(value: OutputFormat.screen, label: Text('Screen')),
          ButtonSegment(value: OutputFormat.a4, label: Text('A4')),
          ButtonSegment(value: OutputFormat.a3, label: Text('A3')),
        ],
        selected: {o.format},
        onSelectionChanged: (v) => onChanged(o.copyWith(format: v.first)),
      ),
      if (!o.inputList)
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          controlAffinity: ListTileControlAffinity.leading,
          title: const Text('Compact'),
          value: compact,
          onChanged: (v) => onChanged(o.copyWith(compact: v ?? false)),
        ),
      Row(children: [
        Text('Text Size', style: TextStyle(color: compact && !o.inputList ? Theme.of(context).disabledColor : null)),
        IconButton(
          icon: const Icon(Icons.remove),
          tooltip: 'Text Size -',
          onPressed: (compact && !o.inputList) || o.textScale <= minScale + 0.01
              ? null
              : () => onChanged(o.copyWith(textScale: step(-0.1))),
        ),
        Text(compact && !o.inputList ? 'Auto' : '${(o.textScale * 100).round()}%'),
        IconButton(
          icon: const Icon(Icons.add),
          tooltip: 'Text Size +',
          onPressed: (compact && !o.inputList) || o.textScale >= maxScale - 0.01
              ? null
              : () => onChanged(o.copyWith(textScale: step(0.1))),
        ),
      ]),
    ]);
  }
}
