import 'package:flutter/material.dart';

/// Small, subtle UI-only signature (the export signature lives in pdf_export_service.dart).
class AppSignature extends StatelessWidget {
  const AppSignature({super.key});
  @override
  Widget build(BuildContext context) => const Padding(
        padding: EdgeInsets.only(top: 2, bottom: 6),
        child: Text('By R. Fenhas',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 10.5, color: Color(0xFF9E9E9E), letterSpacing: 0.3)),
      );
}
