import 'package:flutter/material.dart';
import '../services/app_info.dart';

/// Small, subtle UI-only signature (the export signature lives in pdf_export_service.dart).
class AppSignature extends StatelessWidget {
  final bool showVersion;
  const AppSignature({super.key, this.showVersion = false});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 2, bottom: 6),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('By R. Fenhas',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 10.5, color: Color(0xFF9E9E9E), letterSpacing: 0.3)),
          if (showVersion)
            FutureBuilder<AppInfo>(
              future: AppInfo.load(),
              builder: (c, s) => (s.data == null || s.data!.version.isEmpty)
                  ? const SizedBox.shrink()
                  : Text('v${s.data!.version}',
                      style: const TextStyle(fontSize: 9, color: Color(0xFFB0B0B0))),
            ),
        ]),
      );
}
