import 'dart:typed_data';
import 'package:flutter/material.dart';

/// Page-oriented preview of the rendered Scene Sheet pages (the same rasters that are exported).
/// Zoom/pan only transforms the picture; it never changes the document layout or font sizes.
class ScenePageViewer extends StatefulWidget {
  final List<Uint8List> pages;
  final bool busy;
  final ValueChanged<int>? onPageChanged;
  const ScenePageViewer({super.key, required this.pages, this.busy = false, this.onPageChanged});
  @override
  State<ScenePageViewer> createState() => _ScenePageViewerState();
}

class _ScenePageViewerState extends State<ScenePageViewer> {
  final tc = TransformationController();
  int page = 0;
  static const _max = 8.0;

  @override
  void didUpdateWidget(ScenePageViewer old) {
    super.didUpdateWidget(old);
    if (page >= widget.pages.length) {
      page = widget.pages.isEmpty ? 0 : widget.pages.length - 1;
      widget.onPageChanged?.call(page);
    }
  }

  @override
  void dispose() {
    tc.dispose();
    super.dispose();
  }

  void _zoom(double f, Size vp) {
    final s = tc.value.getMaxScaleOnAxis();
    final ns = (s * f).clamp(1.0, _max);
    if (ns <= 1.001) {
      tc.value = Matrix4.identity();
      return;
    }
    final k = ns / s;
    final c = vp.center(Offset.zero);
    tc.value = Matrix4.translationValues(c.dx, c.dy, 0) *
        Matrix4.diagonal3Values(k, k, 1) *
        Matrix4.translationValues(-c.dx, -c.dy, 0) *
        tc.value;
  }

  void _go(int d) {
    setState(() {
      page = (page + d).clamp(0, widget.pages.length - 1).toInt();
    });
    tc.value = Matrix4.identity();
    widget.onPageChanged?.call(page);
  }

  @override
  Widget build(BuildContext context) {
    final n = widget.pages.length;
    Size vp = Size.zero;
    return Column(children: [
      if (widget.busy) const LinearProgressIndicator(minHeight: 2),
      Expanded(
        child: Container(
          color: const Color(0xFFBDBDBD),
          child: n == 0
              ? const SizedBox.expand()
              : LayoutBuilder(builder: (c, box) {
                  vp = box.biggest;
                  return InteractiveViewer(
                    transformationController: tc,
                    minScale: 1,
                    maxScale: _max,
                    child: SizedBox(
                      width: box.maxWidth,
                      height: box.maxHeight,
                      child: Image.memory(widget.pages[page], fit: BoxFit.contain, gaplessPlayback: true),
                    ),
                  );
                }),
        ),
      ),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Row(children: [
          IconButton(icon: const Icon(Icons.zoom_out), tooltip: 'Zoom Out', onPressed: n == 0 ? null : () => _zoom(0.8, vp)),
          IconButton(icon: const Icon(Icons.zoom_in), tooltip: 'Zoom In', onPressed: n == 0 ? null : () => _zoom(1.25, vp)),
          IconButton(
              icon: const Icon(Icons.fit_screen),
              tooltip: 'Fit to Screen',
              onPressed: n == 0 ? null : () => tc.value = Matrix4.identity()),
        ]),
        Row(children: [
          IconButton(icon: const Icon(Icons.chevron_left), tooltip: 'Previous page', onPressed: page > 0 ? () => _go(-1) : null),
          Text(n == 0 ? '' : 'Page ${page + 1} of $n'),
          IconButton(icon: const Icon(Icons.chevron_right), tooltip: 'Next page', onPressed: page < n - 1 ? () => _go(1) : null),
        ]),
      ]),
    ]);
  }
}
