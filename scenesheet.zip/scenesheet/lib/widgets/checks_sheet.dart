import 'package:flutter/material.dart';
import '../services/checks_service.dart';

void showChecksSheet(BuildContext context, List<CheckItem> items) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (c) => SafeArea(
      child: ListView(padding: const EdgeInsets.all(16), shrinkWrap: true, children: [
        const Text('Pre-show checks', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
        const SizedBox(height: 4),
        const Text(ChecksService.scope, style: TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        if (items.isEmpty) const Text('Nothing to report for the data that was read.'),
        for (final i in items)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(i.level == CheckLevel.warning ? Icons.warning_amber : Icons.info_outline,
                color: i.level == CheckLevel.warning ? Colors.amber : null),
            title: Text(i.title),
            subtitle: Text('${i.detail}${i.channels.isEmpty ? '' : '\nChannels: ${i.channels.join(', ')}'}'),
          ),
      ]),
    ),
  );
}
