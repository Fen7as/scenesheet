SceneSheet - project notes

Version name: edit `version:` in pubspec.yaml (the number before the +), e.g. `version: 0.9.0+1`.
  0.8.0 is the current development baseline; 1.0.0 is reserved for the first stable release.
Build number (Android versionCode): computed by the workflow (ci/build.yml -> .github/workflows/build.yml) as
  minutes since 2026-01-01 UTC and passed with --build-number, so it always increases (reruns included) and
  overrides the number after the + in pubspec.yaml (that one is only used for local builds).
Workflow: copy ci/build.yml to .github/workflows/build.yml in the repository, next to scenesheet.zip.
  It runs `flutter analyze` (errors fail) and `flutter test` (failures fail) before building the APK.
Launcher label ("SceneSheet") and the app icon (design/android_res) are re-applied after `flutter create`.
