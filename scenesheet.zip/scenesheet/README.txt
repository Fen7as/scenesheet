cd scenesheet
flutter create --project-name scenesheet --platforms android --org com.scenesheet .
(answer: keep existing files; lib/ and pubspec.yaml are already here)
flutter pub get
flutter build apk --release
